"""
SECOP Reporte HTML v2.0 — Ferretería
Lee siempre desde el CSV maestro (oportunidades.csv).
Uso standalone : python secop_reporte.py
Uso como módulo: from secop_reporte import generar_reporte, generar_reporte_desde_csv
"""

import os, re, sys, html as html_lib, duckdb, pandas as pd
from datetime import datetime

OUTPUT_DIR  = "files_output"
CSV_MAESTRO = os.path.join(OUTPUT_DIR, "oportunidades.csv")
REPORTE_PATH = os.path.join(OUTPUT_DIR, "reporte_oportunidades.html")  # siempre el mismo archivo

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SECOP · Oportunidades Ferretería</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: #f8f9fc; color: #1a202c; font-family: 'Inter', sans-serif; font-size: 14px; }}

  .header {{
    background: #fff; border-bottom: 1px solid #e2e8f0;
    padding: 18px 32px; display: flex; align-items: center;
    justify-content: space-between; position: sticky; top: 0; z-index: 100;
    box-shadow: 0 1px 3px rgba(0,0,0,.06);
  }}
  .header-left {{ display: flex; align-items: center; gap: 14px; }}
  .header h1 {{ font-size: 17px; font-weight: 700; }}
  .header .sub {{ font-size: 12px; color: #718096; margin-top: 2px; }}
  .badge {{ background: #ebf8f4; color: #1a9e7a; font-weight: 600; font-size: 12px; padding: 5px 14px; border-radius: 20px; border: 1px solid #b2e8d8; }}

  .kpis {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(155px, 1fr)); gap: 14px; padding: 24px 32px 8px; }}
  .kpi {{ background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px 20px; box-shadow: 0 1px 3px rgba(0,0,0,.04); }}
  .kpi .label {{ font-size: 11px; color: #718096; font-weight: 500; text-transform: uppercase; letter-spacing: .06em; }}
  .kpi .value {{ font-size: 22px; font-weight: 700; margin-top: 6px; }}
  .kpi.green  .value {{ color: #1a9e7a; }}
  .kpi.blue   .value {{ color: #3b82f6; }}
  .kpi.yellow .value {{ color: #d97706; }}
  .kpi.purple .value {{ color: #7c3aed; }}
  .kpi.gray   .value {{ color: #94a3b8; }}

  .filters {{ padding: 20px 32px 14px; display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }}
  .filters input, .filters select {{
    background: #fff; border: 1px solid #e2e8f0; color: #1a202c;
    padding: 9px 14px; border-radius: 8px; font-size: 13px;
    outline: none; font-family: inherit; box-shadow: 0 1px 2px rgba(0,0,0,.04);
  }}
  .filters input {{ width: 300px; }}
  .filters input:focus, .filters select:focus {{ border-color: #1a9e7a; box-shadow: 0 0 0 3px rgba(26,158,122,.1); }}
  .count {{ font-size: 12px; color: #94a3b8; margin-left: auto; font-weight: 500; }}

  .section-label {{ padding: 0 32px 10px; font-size: 11px; font-weight: 600; color: #94a3b8; text-transform: uppercase; letter-spacing: .08em; }}

  .table-wrap {{ padding: 0 32px 40px; overflow-x: auto; }}
  table {{ width: 100%; border-collapse: separate; border-spacing: 0; }}
  thead th {{
    background: #f1f5f9; color: #64748b; font-size: 11px; font-weight: 600;
    text-transform: uppercase; letter-spacing: .06em; padding: 11px 16px;
    text-align: left; border-top: 1px solid #e2e8f0; border-bottom: 1px solid #e2e8f0;
    cursor: pointer; user-select: none; white-space: nowrap;
  }}
  thead th:first-child {{ border-radius: 8px 0 0 0; border-left: 1px solid #e2e8f0; }}
  thead th:last-child  {{ border-radius: 0 8px 0 0; border-right: 1px solid #e2e8f0; }}
  thead th:hover {{ color: #1a202c; background: #e8edf4; }}
  thead th.sort-asc::after  {{ content: ' ↑'; color: #1a9e7a; }}
  thead th.sort-desc::after {{ content: ' ↓'; color: #1a9e7a; }}
  tbody tr {{ background: #fff; transition: background .1s; }}
  tbody tr:hover {{ background: #f8faff; }}
  tbody td {{ padding: 13px 16px; vertical-align: top; border-bottom: 1px solid #f1f5f9; border-left: 1px solid #f1f5f9; }}
  tbody td:last-child {{ border-right: 1px solid #f1f5f9; }}

  .ref     {{ font-weight: 600; color: #3b82f6; font-size: 12px; line-height: 1.4; }}
  .entidad {{ font-size: 11px; color: #94a3b8; margin-top: 3px; }}
  .fecha-pub {{ font-size: 10px; color: #cbd5e1; margin-top: 2px; }}
  .desc    {{ font-size: 12px; color: #374151; max-width: 360px; line-height: 1.5; }}
  .cuantia {{ font-weight: 700; color: #1a9e7a; white-space: nowrap; font-size: 14px; }}
  .cuantia-full {{ font-size: 10px; color: #94a3b8; margin-top: 2px; }}
  .fecha   {{ font-size: 11px; color: #374151; white-space: nowrap; }}
  .fecha-label {{ font-size: 10px; color: #94a3b8; }}

  .tag {{ display: inline-block; font-size: 10px; font-weight: 600; padding: 2px 9px; border-radius: 20px; margin: 2px 2px 0 0; line-height: 1.6; }}
  .tag-region {{ background: #eff6ff; color: #3b82f6; border: 1px solid #bfdbfe; }}
  .tag-kw     {{ background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }}
  .tag-obra   {{ background: #fff7ed; color: #c2410c; border: 1px solid #fed7aa; }}
  .tag-tipo   {{ background: #faf5ff; color: #7c3aed; border: 1px solid #e9d5ff; }}

  .btn-ver {{ display: inline-block; color: #fff; background: #3b82f6; text-decoration: none; font-size: 11px; font-weight: 600; padding: 6px 12px; border-radius: 6px; white-space: nowrap; transition: background .15s; }}
  .btn-ver:hover {{ background: #2563eb; }}
  .docs-badge {{ display: inline-flex; align-items: center; gap: 4px; background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; font-size: 11px; font-weight: 600; padding: 3px 8px; border-radius: 6px; }}
  .no-docs {{ color: #cbd5e1; font-size: 12px; }}
  tbody tr.cerrada {{ opacity: .5; }}
  .tag-cerrada {{ background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }}
  .tag-abierta {{ background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }}

  .footer {{ text-align: center; padding: 24px; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; background: #fff; }}
  .footer strong {{ color: #64748b; }}
</style>
</head>
<body>

<div class="header">
  <div class="header-left">
    <div style="font-size:22px">🔧</div>
    <div>
      <h1>Oportunidades SECOP · Ferretería</h1>
      <div class="sub">Acumulado: {periodo} &nbsp;·&nbsp; Actualizado: {generado}</div>
    </div>
  </div>
  <span class="badge">✓ {n_oportunidades} oportunidades</span>
</div>

<div class="kpis">
  <div class="kpi green"><div class="label">Oportunidades</div><div class="value">{n_oportunidades}</div></div>
  <div class="kpi green"><div class="label">Nuevas hoy</div><div class="value">{n_nuevas_hoy}</div></div>
  <div class="kpi blue"><div class="label">Cuantía total</div><div class="value">{cuantia_total}</div></div>
  <div class="kpi yellow"><div class="label">Promedio</div><div class="value">{cuantia_prom}</div></div>
  <div class="kpi purple"><div class="label">Entidades</div><div class="value">{n_entidades}</div></div>
  <div class="kpi gray"><div class="label">Tolima</div><div class="value">{n_tolima}</div></div>
  <div class="kpi gray"><div class="label">Cundinamarca</div><div class="value">{n_cundi}</div></div>
  <div class="kpi gray"><div class="label">Boyacá</div><div class="value">{n_boyaca}</div></div>
</div>

<div class="filters">
  <input type="text" id="buscar" placeholder="🔍  Buscar entidad, descripción, referencia..." oninput="filtrarTabla()">
  <select id="filtroRegion" onchange="filtrarTabla()">
    <option value="">Todas las regiones</option>
    {opciones_region}
  </select>
  <select id="filtroKw" onchange="filtrarTabla()">
    <option value="">Todas las actividades</option>
    {opciones_kw}
  </select>
  <select id="filtroEstado" onchange="filtrarTabla()">
    <option value="abiertas" selected>Solo abiertas</option>
    <option value="cerradas">Solo cerradas</option>
    <option value="">Todas (abiertas y cerradas)</option>
  </select>
  <select id="filtroFecha" onchange="filtrarTabla()">
    <option value="">Todas las fechas</option>
    {opciones_fecha}
  </select>
  <span class="count" id="countLabel"></span>
</div>

<div class="section-label">Resultados</div>

<div class="table-wrap">
  <table id="tabla">
    <thead>
      <tr>
        <th onclick="sortTabla(0)">Referencia / Entidad</th>
        <th onclick="sortTabla(1)">Descripción</th>
        <th onclick="sortTabla(2)">Etiquetas</th>
        <th onclick="sortTabla(3)">Cuantía</th>
        <th onclick="sortTabla(4)">Cierre</th>
        <th>Docs</th>
        <th>Enlace</th>
      </tr>
    </thead>
    <tbody id="tbody">{filas}</tbody>
  </table>
</div>

<div class="footer"><strong>SECOP II Scraper</strong> · MetriLab · {generado}</div>

<script>
const allRows = Array.from(document.querySelectorAll('#tbody tr'));
let sortCol = 3, sortDir = -1;

function estadoFila(tr) {{
  // Sin fecha de cierre parseable -> se trata como abierta (no ocultar algo que podría estar vigente)
  const c = tr.dataset.cierre;
  if (!c) return 'abiertas';
  return new Date(c) >= new Date() ? 'abiertas' : 'cerradas';
}}

function marcarEstados() {{
  allRows.forEach(tr => {{
    const est = estadoFila(tr);
    tr.dataset.estado = est;
    tr.classList.toggle('cerrada', est === 'cerradas');
    const tag = tr.querySelector('.tag-estado');
    if (tag) {{
      tag.textContent = est === 'cerradas' ? 'Cerrada' : 'Abierta';
      tag.className = 'tag tag-estado ' + (est === 'cerradas' ? 'tag-cerrada' : 'tag-abierta');
    }}
  }});
}}

function filtrarTabla() {{
  const q    = document.getElementById('buscar').value.toLowerCase();
  const reg  = document.getElementById('filtroRegion').value.toLowerCase();
  const kw   = document.getElementById('filtroKw').value.toLowerCase();
  const fech = document.getElementById('filtroFecha').value.toLowerCase();
  const est  = document.getElementById('filtroEstado').value;
  let vis = 0;
  allRows.forEach(tr => {{
    const txt  = tr.textContent.toLowerCase();
    const r    = tr.dataset.region.toLowerCase();
    const k    = tr.dataset.kw.toLowerCase();
    const f    = tr.dataset.fecha.toLowerCase();
    const ok   = (!q || txt.includes(q)) && (!reg || r === reg) && (!kw || k.split('|').includes(kw)) && (!fech || f === fech) && (!est || tr.dataset.estado === est);
    tr.style.display = ok ? '' : 'none';
    if (ok) vis++;
  }});
  document.getElementById('countLabel').textContent = vis + ' resultado' + (vis !== 1 ? 's' : '');
}}

function sortTabla(col) {{
  const ths = document.querySelectorAll('thead th');
  ths.forEach(th => th.classList.remove('sort-asc','sort-desc'));
  if (sortCol === col) sortDir *= -1;
  else {{ sortCol = col; sortDir = col === 3 ? -1 : 1; }}
  ths[col].classList.add(sortDir === 1 ? 'sort-asc' : 'sort-desc');
  const tbody = document.getElementById('tbody');
  allRows.slice().sort((a, b) => {{
    let av = a.cells[col]?.dataset?.val ?? a.cells[col]?.textContent ?? '';
    let bv = b.cells[col]?.dataset?.val ?? b.cells[col]?.textContent ?? '';
    if (/^\\d{{4}}-\\d{{2}}-\\d{{2}}/.test(av) || /^\\d{{4}}-\\d{{2}}-\\d{{2}}/.test(bv)) {{
      if (!av) return 1; if (!bv) return -1;          // sin fecha al final
      return av.localeCompare(bv) * sortDir;
    }}
    const an = Number(av), bn = Number(bv);
    if (av !== '' && bv !== '' && !isNaN(an) && !isNaN(bn)) return (an - bn) * sortDir;
    return av.localeCompare(bv, 'es') * sortDir;
  }}).forEach(r => tbody.appendChild(r));
}}

document.addEventListener('DOMContentLoaded', () => {{ marcarEstados(); filtrarTabla(); sortTabla(3); }});
</script>
</body>
</html>"""

FILA_TEMPLATE = """<tr data-region="{region}" data-kw="{kw_data}" data-fecha="{fecha_pub_dia}" data-cierre="{cierre_iso}">
  <td><div class="ref">{referencia}</div><div class="entidad">{entidad}</div><div class="fecha-pub">📅 {fecha_pub}</div></td>
  <td><div class="desc">{descripcion}</div></td>
  <td><span class="tag tag-region">{region}</span><br>{tags_actividad}<span class="tag tag-tipo">{tipo}</span></td>
  <td data-val="{cuantia_val}"><div class="cuantia">{cuantia_fmt}</div><div class="cuantia-full">{cuantia_full}</div></td>
  <td data-val="{cierre_iso}"><div class="fecha-label">Cierre</div><div class="fecha">{fecha_limite}</div><span class="tag tag-estado"></span></td>
  <td>{docs_html}</td>
  <td><a class="btn-ver" href="{url}" target="_blank">Ver →</a></td>
</tr>"""


def fmt_cop_short(val):
    try:
        v = float(val)
        if v >= 1_000_000_000: return f"$ {v/1_000_000_000:.1f} B"
        if v >= 1_000_000:     return f"$ {v/1_000_000:.0f} M"
        return f"$ {v:,.0f}"
    except: return "—"

def fmt_cop_full(val):
    try:    return f"COP {float(val):,.0f}"
    except: return ""

def limpiar(val, default=""):
    """Normaliza a string y escapa HTML (descripciones con <, >, comillas no rompen el reporte)."""
    if val is None or (isinstance(val, float) and val != val): return default
    s = str(val).strip()
    return html_lib.escape(s, quote=True) if s else default

_RE_FECHA_SECOP = re.compile(
    r"(\d{1,2})/(\d{1,2})/(\d{4})"                      # d/m/aaaa (día y mes con 1 o 2 dígitos)
    r"(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?"             # h:mm[:ss]
    r"(?:\s*([ap])\.?\s*m\.?)?)?",                       # AM/PM, a. m./p. m. (opcional)
    re.IGNORECASE,
)
_RE_FECHA_ISO = re.compile(r"(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?")


def parsear_fecha(fecha_str):
    """
    Convierte una fecha de SECOP a (datetime, tiene_hora) o (None, False).
    Acepta '6/10/2026 8:24 PM (UTC -5 horas)', '28/09/2026 9:48 p. m.',
    '06/10/2026 20:24', '2026-10-06 20:24:00', '6/10/2026'.
    SECOP siempre es día/mes/año.
    """
    if fecha_str is None or (isinstance(fecha_str, float) and fecha_str != fecha_str):
        return None, False
    s = html_lib.unescape(str(fecha_str)).strip()
    if not s:
        return None, False

    m = _RE_FECHA_SECOP.search(s)
    if m:
        d, mes, a, h, mi, se, ampm = m.groups()
        try:
            if h is None:
                return datetime(int(a), int(mes), int(d)), False
            h = int(h)
            if ampm:
                ampm = ampm.lower()
                if not 1 <= h <= 12:
                    return None, False
                if ampm == "p" and h != 12: h += 12
                if ampm == "a" and h == 12: h = 0
            return datetime(int(a), int(mes), int(d), h, int(mi), int(se or 0)), True
        except ValueError:
            return None, False

    m = _RE_FECHA_ISO.search(s)
    if m:
        a, mes, d, h, mi, se = m.groups()
        try:
            if h is None:
                return datetime(int(a), int(mes), int(d)), False
            return datetime(int(a), int(mes), int(d), int(h), int(mi), int(se or 0)), True
        except ValueError:
            return None, False
    return None, False


def parsear_cierre(fecha_str) -> str:
    """Fecha límite -> ISO con zona Colombia. Sin hora: abierta hasta el final del día. '' si no se puede."""
    dt, con_hora = parsear_fecha(fecha_str)
    if dt is None:
        return ""
    if not con_hora:
        dt = dt.replace(hour=23, minute=59, second=59)
    return dt.strftime("%Y-%m-%dT%H:%M:%S-05:00")


def extraer_dia(fecha_str):
    """YYYY-MM-DD para el filtro por día."""
    dt, _ = parsear_fecha(fecha_str)
    return dt.strftime("%Y-%m-%d") if dt else ""


def fmt_fecha_mostrar(fecha_str, default="—"):
    """Formato uniforme para la tabla: 06/10/2026 08:24 PM (o solo la fecha si no trae hora)."""
    dt, con_hora = parsear_fecha(fecha_str)
    if dt is None:
        crudo = limpiar(fecha_str, default)
        return crudo.split(" (")[0] if crudo else default
    return dt.strftime("%d/%m/%Y %I:%M %p") if con_hora else dt.strftime("%d/%m/%Y")


def generar_reporte(df: pd.DataFrame, total_input: int, output_path: str, periodo: str = ""):
    """Genera HTML desde un DataFrame. Llamable desde el scraper."""
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    cop = pd.to_numeric(df.get("cuantia_cop", pd.Series(dtype=float)), errors="coerce")
    n   = len(df)

    # KPIs por región
    def count_region(r):
        if "region_detectada" not in df.columns: return 0
        return int((df["region_detectada"] == r).sum())

    # Fechas únicas para filtro por día (se calculan antes para el período)
    if "fecha_publicacion" in df.columns:
        dias = sorted(set(
            d for d in df["fecha_publicacion"].apply(extraer_dia) if d
        ), reverse=True)
    else:
        dias = []

    if not periodo:
        periodo = f"{dias[-1]} → {dias[0]}" if dias else "acumulado"

    hoy = datetime.now().strftime("%Y-%m-%d")
    n_nuevas_hoy = (int((df["fecha_captura"].astype(str) == hoy).sum())
                    if "fecha_captura" in df.columns else n)

    kpi = dict(
        n_oportunidades = n,
        cuantia_total   = fmt_cop_short(cop.sum()),
        cuantia_prom    = fmt_cop_short(cop.mean()),
        n_entidades     = df["entidad"].nunique() if "entidad" in df.columns else "—",
        n_tolima        = count_region("TOLIMA"),
        n_cundi         = count_region("CUNDINAMARCA"),
        n_boyaca        = count_region("BOYACA"),
        n_nuevas_hoy    = n_nuevas_hoy,
        periodo         = periodo,
        generado        = datetime.now().strftime("%d/%m/%Y %H:%M"),
    )

    # Opciones filtros
    regiones = sorted(df["region_detectada"].dropna().unique()) if "region_detectada" in df.columns else []
    def lista_actividades(r):
        a = r.get("actividades") if hasattr(r, "get") else None
        if isinstance(a, str) and a.strip():
            return [x.strip() for x in a.split(",") if x.strip()]
        k = r.get("keyword_detectada") if hasattr(r, "get") else None
        return [k] if isinstance(k, str) and k.strip() else []
    keywords = sorted({a for _, r in df.iterrows() for a in lista_actividades(r)})

    opciones_region = "\n    ".join(f'<option value="{r}">{r}</option>' for r in regiones)
    opciones_kw     = "\n    ".join(f'<option value="{k}">{k}</option>' for k in keywords)
    opciones_fecha  = "\n    ".join(f'<option value="{d}">{d}</option>' for d in dias)

    # Filas
    filas_html = []
    for _, r in df.iterrows():
        val = r.get("cuantia_cop")
        try:    val_num = float(val)
        except: val_num = 0

        docs = r.get("num_documentos", 0)
        try:    docs = int(docs)
        except: docs = 0
        docs_html = (f'<span class="docs-badge">📎 {docs}</span>'
                     if docs > 0 else '<span class="no-docs">—</span>')

        tipo_raw = limpiar(r.get("tipo_proceso") or r.get("tipo_filtro"), "")
        tipo_short = (tipo_raw
            .replace("Seleccion_abreviada","Sel.Abrev.")
            .replace("Licitacion_publica","Licitación")
            .replace("Minima_cuantia","Mín.Cuantía")
            .replace("CCE-07-Seleccion_Abreviada_Subasta","Subasta"))[:22]

        fecha_pub_dia = extraer_dia(r.get("fecha_publicacion"))
        fecha_pub     = fmt_fecha_mostrar(r.get("fecha_publicacion"), "")
        fecha_lim     = fmt_fecha_mostrar(r.get("fecha_limite"))
        cierre_iso    = parsear_cierre(r.get("fecha_limite"))

        filas_html.append(FILA_TEMPLATE.format(
            region       = limpiar(r.get("region_detectada"), "—"),
            kw_data      = limpiar("|".join(a.lower() for a in lista_actividades(r))),
            tags_actividad = "".join(f'<span class="tag tag-kw">{limpiar(a)}</span>' for a in lista_actividades(r))
                             + ('<span class="tag tag-obra">Obra</span>'
                                if str(r.get("es_obra")).lower() in ("true", "1") else ""),
            fecha_pub_dia= fecha_pub_dia,
            referencia   = limpiar(r.get("referencia"), "—")[:55],
            entidad      = limpiar(r.get("entidad"), "—")[:65],
            descripcion  = limpiar(r.get("descripcion") or r.get("descripcion_detalle"), "—")[:130],
            tipo         = tipo_short,
            cuantia_val  = f"{val_num:.0f}",
            cuantia_fmt  = fmt_cop_short(val_num),
            cuantia_full = fmt_cop_full(val_num),
            fecha_pub    = fecha_pub,
            fecha_limite = fecha_lim,
            cierre_iso   = cierre_iso,
            docs_html    = docs_html,
            url          = limpiar(r.get("url_detalle"), "#"),
        ))

    html = HTML_TEMPLATE.format(
        **kpi,
        opciones_region = opciones_region,
        opciones_kw     = opciones_kw,
        opciones_fecha  = opciones_fecha,
        filas           = "\n".join(filas_html),
    )

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"  HTML: {output_path}  ({n} oportunidades)")
    return output_path


def generar_reporte_desde_csv(output_path: str = REPORTE_PATH, periodo: str = ""):
    """Lee el CSV maestro y genera el reporte HTML. Para uso standalone."""
    if not os.path.exists(CSV_MAESTRO):
        print(f"[!] CSV maestro no encontrado: {CSV_MAESTRO}")
        return None

    con = duckdb.connect()
    df  = con.execute(f"""
        SELECT * FROM read_csv_auto('{CSV_MAESTRO}')
        ORDER BY cuantia_cop DESC NULLS LAST
    """).fetchdf()
    con.close()

    print(f"  CSV maestro: {len(df)} oportunidades")
    return generar_reporte(df, len(df), output_path, periodo)


if __name__ == "__main__":
    out = generar_reporte_desde_csv()
    print(f"\nListo → sube {out} a netlify.com/drop")