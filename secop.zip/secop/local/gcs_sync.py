"""
Sincronización staging local -> Google Cloud Storage.

- Sube cada archivo, verifica el MD5 contra lo que quedó en GCS y SOLO ENTONCES borra el local.
- metadata.json de un proceso se sube de último y solo si todos sus documentos subieron bien:
  así el analizador en GCP nunca ve un proceso a medias.
- Si algo falla (sin internet, timeout), el archivo queda en staging y la siguiente corrida lo reintenta.

Autenticación: Application Default Credentials.
En el PC, una sola vez:  gcloud auth application-default login
Config: GCS_BUCKET (sin gs://) y GOOGLE_CLOUD_PROJECT en el .env.
"""

import base64
import hashlib
import json
import logging
import mimetypes
import os

log = logging.getLogger("gcs_sync")

_bucket = None


def configurado() -> bool:
    return bool(os.getenv("GCS_BUCKET"))


def _get_bucket():
    global _bucket
    if _bucket is None:
        from google.cloud import storage
        proyecto = os.getenv("GOOGLE_CLOUD_PROJECT") or None
        _bucket = storage.Client(project=proyecto).bucket(os.environ["GCS_BUCKET"])
    return _bucket


def _md5_b64(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return base64.b64encode(h.digest()).decode()


def _content_type(path: str) -> str:
    if path.endswith(".json"):
        return "application/json"
    ct, _ = mimetypes.guess_type(path)
    return ct or "application/octet-stream"


def leer_json(objeto: str):
    """Lee un JSON del bucket. None si no existe."""
    blob = _get_bucket().get_blob(objeto)
    if blob is None:
        return None
    return json.loads(blob.download_as_text())


def subir_archivo(local: str, objeto: str, borrar: bool = False) -> bool:
    """Sube un archivo, verifica MD5 y opcionalmente borra el local. True si quedó bien en GCS."""
    from google.cloud.storage.retry import DEFAULT_RETRY

    bucket = _get_bucket()
    md5 = _md5_b64(local)
    try:
        existente = bucket.get_blob(objeto)
        if existente is not None and existente.md5_hash == md5:
            ok = True  # ya estaba idéntico
        else:
            blob = bucket.blob(objeto)
            # Reintentos explícitos: re-subir el mismo contenido es idempotente
            blob.upload_from_filename(local, content_type=_content_type(local),
                                      retry=DEFAULT_RETRY, timeout=600)
            blob.reload()
            ok = blob.md5_hash == md5
            if not ok:
                log.warning(f"  [gcs] MD5 no coincide tras subir {objeto}")
    except Exception as e:
        log.warning(f"  [gcs] Error subiendo {objeto}: {e}")
        return False

    if ok and borrar:
        os.remove(local)
    return ok


def _borrar_carpetas_vacias(carpeta: str, raiz: str):
    for dirpath, _, _ in sorted(os.walk(carpeta), key=lambda t: len(t[0]), reverse=True):
        if os.path.abspath(dirpath) == os.path.abspath(raiz):
            continue
        try:
            os.rmdir(dirpath)  # solo borra si está vacía
        except OSError:
            pass


def subir_y_limpiar(carpeta: str, raiz: str) -> tuple[int, int]:
    """
    Sube todo lo que haya bajo `carpeta` (el nombre del objeto es la ruta relativa a `raiz`)
    y borra lo local que quedó verificado. Retorna (subidos, fallidos).
    """
    if not os.path.isdir(carpeta):
        return 0, 0

    archivos = []
    for dirpath, _, files in os.walk(carpeta):
        for fn in files:
            archivos.append(os.path.join(dirpath, fn))

    def objeto(path):
        return os.path.relpath(path, raiz).replace(os.sep, "/")

    metas  = [a for a in archivos if os.path.basename(a) == "metadata.json"]
    otros  = [a for a in archivos if os.path.basename(a) != "metadata.json"]
    subidos, fallidos = 0, 0
    dirs_con_fallo = []

    # 1) Documentos y HTML
    for a in otros:
        if subir_archivo(a, objeto(a), borrar=True):
            subidos += 1
        else:
            fallidos += 1
            dirs_con_fallo.append(os.path.abspath(os.path.dirname(a)))

    # 2) metadata.json solo si nada de su proceso falló
    for m in metas:
        dir_proc = os.path.abspath(os.path.dirname(m))
        if any(d == dir_proc or d.startswith(dir_proc + os.sep) for d in dirs_con_fallo):
            log.warning(f"  [gcs] {objeto(m)} queda en staging: hay documentos sin subir")
            fallidos += 1
            continue
        if subir_archivo(m, objeto(m), borrar=True):
            subidos += 1
        else:
            fallidos += 1

    _borrar_carpetas_vacias(carpeta, raiz)
    return subidos, fallidos
