"""
Descargador SECOP II v1.0
- Baja los documentos de las OPORTUNIDADES filtradas (no de todas las licitaciones)
- Los deja en staging/ con la misma estructura del bucket:
      secop/raw/entidad=<NIT>_<entidad>/proceso=<referencia>/
          metadata.json · detalle.html · documentos/<fileId>__<nombre>.pdf
- Sube cada proceso a GCS, verifica y borra lo local (gcs_sync)
- Incremental: lee el metadata.json que ya está en GCS y solo baja fileIds nuevos (adendas)

Uso como módulo : await descargar_y_subir(df_oportunidades)           (lo llama main.py)
Uso standalone  : python descargador.py --abiertas    re-visita las oportunidades abiertas del CSV maestro
                  python descargador.py --abiertas --limite 3            prueba con 3 procesos
                  python descargador.py --abiertas --ref LP-005-2026     solo procesos que coincidan
                  python descargador.py --solo-subir  reintenta subir lo que quedó en staging
Sin GCS_BUCKET en .env los PDFs se quedan en staging/ (útil para revisarlos antes de subir).
"""

import argparse
import asyncio
import hashlib
import json
import logging
import mimetypes
import os
import re
import sys
import unicodedata
from datetime import datetime
from urllib.parse import unquote

import pandas as pd
from bs4 import BeautifulSoup

import gcs_sync
from sesion import BASE_URL, BUSQUEDA_URL, abrir_navegador, es_pagina_error, resolver_captcha

log = logging.getLogger("descargador")

STAGING_DIR  = os.getenv("STAGING_DIR", "staging")
GCS_PREFIX   = os.getenv("GCS_PREFIX", "secop").strip("/")
DELAY_DOC    = 0.8
DOWNLOAD_URL = f"{BASE_URL}/Public/Tendering/OpportunityDetail/DownloadFile?documentFileId={{}}"

PAT_DOC = re.compile(
    r"DownloadFile'\s*\+\s*'\?'\s*\+\s*'documentFileId='\s*\+\s*'(\d+)'", re.I
)

EXT_POR_TIPO = {
    "application/pdf": ".pdf",
    "application/zip": ".zip",
    "application/x-zip-compressed": ".zip",
    "application/x-rar-compressed": ".rar",
    "application/vnd.rar": ".rar",
    "application/msword": ".doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/vnd.ms-excel": ".xls",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
}


# ──────────────────────────────────────────────────────────────────────
# Utilidades de nombres y rutas
# ──────────────────────────────────────────────────────────────────────

def slug(texto, max_len: int = 60) -> str:
    """Sin tildes, sin espacios, solo [a-z0-9._-]. Seguro para Windows y para GCS."""
    t = unicodedata.normalize("NFKD", str(texto or "")).encode("ascii", "ignore").decode()
    t = re.sub(r"[^A-Za-z0-9._-]+", "-", t)
    t = re.sub(r"-{2,}", "-", t).strip("-._").lower()
    return t[:max_len].strip("-._") or "sin-nombre"


def _vacio(v) -> bool:
    return v is None or (isinstance(v, float) and v != v) or str(v).strip() in ("", "nan", "None")


def _nit(v) -> str:
    if _vacio(v):
        return ""
    s = str(v).strip()
    if re.fullmatch(r"\d+\.0", s):  # NIT leído como float desde CSV
        s = s[:-2]
    return re.sub(r"[^0-9-]", "", s)


def notice_uid(row: dict) -> str:
    if not _vacio(row.get("notice_uid")):
        return str(row["notice_uid"])
    m = re.search(r"noticeUID=([^&]+)", str(row.get("url_detalle") or ""))
    return m.group(1) if m else ""


def referencia_base(ref) -> str:
    """
    'LP-005-2026 (Presentación de oferta)' -> 'LP-005-2026'
    'MS-SAMC-015-2026 (Manifestación de interés (Menor Cuantía)) (...)' -> 'MS-SAMC-015-2026'
    La fase cambia; el proceso no.
    """
    return str(ref or "").split("(")[0].strip() or str(ref or "").strip()


def ruta_proceso(row: dict) -> str:
    """
    Prefijo del objeto en GCS (y de la carpeta en staging) para un proceso.
    Solo usa el nombre de la entidad: el NIT no siempre viene en el scraping y si la ruta
    dependiera de él, el mismo proceso cambiaría de carpeta el día que aparezca. El NIT va en metadata.json.
    """
    ent = slug(row.get("entidad"), 60)
    return f"{GCS_PREFIX}/raw/entidad={ent}/proceso={slug(referencia_base(row.get('referencia')), 60)}"


def carpeta_local(rel: str) -> str:
    return os.path.join(STAGING_DIR, *rel.split("/"))


def nombre_desde_cd(cd: str | None) -> str | None:
    """Nombre real del archivo desde el header Content-Disposition."""
    if not cd:
        return None
    m = re.search(r"filename\*\s*=\s*(?:UTF-8'[^']*')?([^;]+)", cd, re.I)
    if m:
        return unquote(m.group(1).strip().strip('"'))
    m = re.search(r'filename\s*=\s*"?([^";]+)"?', cd, re.I)
    return m.group(1).strip() if m else None


# Extensiones que reconocemos como tales (el resto de puntos es parte del nombre: "1.BPIN.pdf")
EXT_CONOCIDAS = {
    ".pdf", ".doc", ".docx", ".docm", ".xls", ".xlsx", ".xlsm", ".xlsb", ".ppt", ".pptx",
    ".odt", ".ods", ".rtf", ".txt", ".csv", ".xml", ".html", ".htm", ".msg", ".eml",
    ".zip", ".rar", ".7z", ".gz", ".tar", ".kmz", ".kml", ".dwg", ".dxf", ".shp",
    ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".gif", ".mp4",
}
# Familias por firma interna: si la extensión original es de la familia detectada, se respeta
FAMILIAS = {
    "pdf": {".pdf"},
    "pk":  {".zip", ".docx", ".docm", ".xlsx", ".xlsm", ".xlsb", ".pptx", ".odt", ".ods", ".kmz"},
    "ole": {".doc", ".xls", ".ppt", ".msg"},
    "rar": {".rar"},
    "7z":  {".7z"},
    "jpg": {".jpg", ".jpeg"},
    "png": {".png"},
}


def _es_ext(ext: str) -> bool:
    e = (ext or "").lower()
    return e in EXT_CONOCIDAS or bool(re.fullmatch(r"\.z\d{2}", e))  # .z01, .z02: zip dividido


def familia_por_contenido(body: bytes) -> str | None:
    """Tipo real del archivo por sus primeros bytes."""
    cab = body[:8]
    if cab.startswith(b"%PDF"):
        return "pdf"
    if cab.startswith(b"PK\x03\x04"):
        return "pk"
    if cab.startswith(b"\xd0\xcf\x11\xe0"):
        return "ole"
    if cab.startswith(b"Rar!"):
        return "rar"
    if cab.startswith(b"7z\xbc\xaf"):
        return "7z"
    if cab[:3] == b"\xff\xd8\xff":
        return "jpg"
    if cab.startswith(b"\x89PNG"):
        return "png"
    return None


def _ext_por_familia(fam: str, body: bytes) -> str:
    if fam == "pk":
        muestra = body[:200_000]
        if b"word/" in muestra:
            return ".docx"
        if b"xl/" in muestra:
            return ".xlsx"
        return ".zip"
    return {"pdf": ".pdf", "ole": ".doc", "rar": ".rar", "7z": ".7z",
            "jpg": ".jpg", "png": ".png"}[fam]


def ext_por_contenido(body: bytes) -> str | None:
    fam = familia_por_contenido(body)
    return _ext_por_familia(fam, body) if fam else None


def nombre_archivo(file_id: str, nombre: str | None, content_type: str,
                   body: bytes = b"", ext_respaldo: str | None = None) -> str:
    """
    <fileId>__<nombre>.<ext>
    - La extensión original se respeta si es coherente con el contenido (xlsm sigue siendo xlsm).
    - El contenido solo la corrige si falta o si es incompatible (.bin que en realidad es PDF).
    """
    nombre = (nombre or "").strip()
    base, ext = os.path.splitext(nombre)
    if not _es_ext(ext):
        base, ext = nombre, ""
    if not ext and ext_respaldo and _es_ext(ext_respaldo):
        ext = ext_respaldo

    fam = familia_por_contenido(body) if body else None
    if fam and ext.lower() not in FAMILIAS[fam]:
        ext = _ext_por_familia(fam, body)          # incompatible o faltante: manda el contenido
    elif not ext:
        ct = (content_type or "").split(";")[0].strip().lower()
        ext = EXT_POR_TIPO.get(ct) or mimetypes.guess_extension(ct) or ".bin"
    return f"{file_id}__{slug(base or 'documento', 80)}{ext.lower()}"


def _limpio(v):
    """Valores serializables a JSON (sin NaN ni tipos numpy)."""
    if _vacio(v):
        return None
    if hasattr(v, "item"):
        v = v.item()
    return v


# ──────────────────────────────────────────────────────────────────────
# Documentos del proceso
# ──────────────────────────────────────────────────────────────────────

def extraer_docs_html(html: str) -> list[dict]:
    """fileIds + nombre visible desde el HTML del detalle (incluye adendas nuevas)."""
    soup, docs, vistos = BeautifulSoup(html, "html.parser"), [], set()
    for tag in soup.find_all(onclick=True):
        m = PAT_DOC.search(tag.get("onclick", ""))
        if not m or m.group(1) in vistos:
            continue
        file_id = m.group(1)
        vistos.add(file_id)
        nombre = None
        tr = tag.find_parent("tr")
        if tr and tr.find_all("td"):
            nombre = tr.find_all("td")[0].get_text(" ", strip=True) or None
        docs.append({"documentFileId": file_id, "nombre": nombre})
    return docs


def docs_del_manifest(row: dict) -> list[dict]:
    ruta = row.get("ruta_manifest")
    if not _vacio(ruta) and os.path.exists(str(ruta)):
        with open(str(ruta), encoding="utf-8") as f:
            m = json.load(f)
        return [{"documentFileId": str(d["documentFileId"]), "nombre": d.get("nombre")}
                for d in m.get("documentos", [])]
    if not _vacio(row.get("docs_urls")):
        return [{"documentFileId": x.strip(), "nombre": None}
                for x in str(row["docs_urls"]).split("|") if x.strip()]
    return []


async def bajar_doc(page, file_id: str):
    """Retorna (bytes, nombre_real, content_type) o None. Primero request directo; si no, clic."""
    try:
        resp = await page.context.request.get(
            DOWNLOAD_URL.format(file_id), headers={"Referer": page.url}, timeout=120_000
        )
        ct = resp.headers.get("content-type", "")
        if resp.ok and "text/html" not in ct.lower():
            body = await resp.body()
            if body:
                return body, nombre_desde_cd(resp.headers.get("content-disposition")), ct
    except Exception as e:
        log.info(f"      request directo falló ({file_id}): {e}")

    # Fallback: hacer clic en el botón real de la página (replica el JS de SECOP)
    try:
        loc = page.locator(f'[onclick*="{file_id}"]').first
        if await loc.count() == 0:
            return None
        async with page.expect_download(timeout=120_000) as info:
            await loc.click()
        dl = await info.value
        ruta_tmp = await dl.path()
        with open(ruta_tmp, "rb") as f:
            body = f.read()
        sugerido = dl.suggested_filename or ""
        if re.fullmatch(r"[0-9a-fA-F-]{32,36}", os.path.splitext(sugerido)[0]):
            sugerido = ""  # nombre temporal (UUID): mejor usar el nombre visible de la página
        ct = mimetypes.guess_type(sugerido)[0] or ""
        return body, sugerido or None, ct
    except Exception as e:
        log.info(f"      clic de descarga falló ({file_id}): {e}")
        return None


async def descargar_proceso(page, row: dict, meta_prev: dict | None) -> dict | None:
    """
    Baja lo que falte de un proceso a staging. Retorna el metadata escrito,
    o None si no había nada nuevo que bajar.
    """
    rel     = ruta_proceso(row)
    carpeta = carpeta_local(rel)
    url     = row.get("url_detalle")
    if _vacio(url):
        log.info(f"    sin url_detalle: {row.get('referencia')}")
        return None

    await page.goto(str(url), wait_until="networkidle", timeout=30_000)
    await asyncio.sleep(1.0)
    await resolver_captcha(page)
    html = await page.content()
    if es_pagina_error(html):
        raise RuntimeError("página de error / sesión expirada")

    # Documentos: los que muestra hoy la página + los del manifest (unión por fileId)
    docs = {d["documentFileId"]: d for d in docs_del_manifest(row)}
    for d in extraer_docs_html(html):
        docs[d["documentFileId"]] = {**docs.get(d["documentFileId"], {}), **{k: v for k, v in d.items() if v}}

    previos    = {d["documentFileId"]: d for d in (meta_prev or {}).get("documentos", [])
                  if d.get("estado") == "ok"}
    pendientes = [d for fid, d in docs.items() if fid not in previos]

    if meta_prev is not None and not pendientes:
        return None  # ya está todo en GCS

    os.makedirs(os.path.join(carpeta, "documentos"), exist_ok=True)
    with open(os.path.join(carpeta, "detalle.html"), "w", encoding="utf-8") as f:
        f.write(html)

    resultado = list(previos.values())
    for d in pendientes:
        fid = d["documentFileId"]
        r = await bajar_doc(page, fid)
        if r is None:
            resultado.append({"documentFileId": fid, "nombre_original": d.get("nombre"),
                              "estado": "error"})
            log.info(f"      ✗ doc {fid}")
            continue
        body, nombre_real, ct = r
        if body[:15].lstrip().lower().startswith((b"<!doctype", b"<html")):
            resultado.append({"documentFileId": fid, "nombre_original": d.get("nombre"),
                              "estado": "error", "motivo": "SECOP devolvió HTML en vez del archivo"})
            log.info(f"      ✗ doc {fid}: devolvió HTML")
            continue
        fname = nombre_archivo(fid, nombre_real or d.get("nombre"), ct, body)
        with open(os.path.join(carpeta, "documentos", fname), "wb") as f:
            f.write(body)
        resultado.append({
            "documentFileId":  fid,
            "nombre_original": nombre_real or d.get("nombre"),
            "archivo":         f"{rel}/documentos/{fname}",
            "bytes":           len(body),
            "sha256":          hashlib.sha256(body).hexdigest(),
            "content_type":    ct.split(";")[0].strip() or None,
            "estado":          "ok",
            "descargado_en":   datetime.now().isoformat(timespec="seconds"),
        })
        await asyncio.sleep(DELAY_DOC)

    campos = ["referencia", "entidad", "descripcion", "descripcion_detalle", "objeto",
              "tipo_proceso", "tipo_filtro", "cuantia_cop", "fecha_publicacion", "fecha_limite",
              "region_detectada", "keyword_detectada", "url_detalle"]
    meta = {k: _limpio(row.get(k)) for k in campos}
    meta.update({
        "notice_uid":         notice_uid(row) or None,
        "nit":                _nit(row.get("nit")) or None,
        "ruta_gcs":           rel,
        "documentos":         resultado,
        "num_documentos":     len(resultado),
        "descarga_completa":  all(d.get("estado") == "ok" for d in resultado),
        "actualizado_en":     datetime.now().isoformat(timespec="seconds"),
    })
    # Una sola línea: BigQuery lo lee como NEWLINE_DELIMITED_JSON
    with open(os.path.join(carpeta, "metadata.json"), "w", encoding="utf-8") as f:
        f.write(json.dumps(meta, ensure_ascii=False))

    nuevos = sum(1 for d in resultado if d.get("estado") == "ok") - len(previos)
    log.info(f"    ✓ {row.get('referencia')}: {nuevos} docs nuevos · {len(resultado)} total")
    return meta


# ──────────────────────────────────────────────────────────────────────
# Orquestación
# ──────────────────────────────────────────────────────────────────────

def subir_pendientes():
    """Barrido: sube lo que haya quedado en staging de corridas anteriores."""
    if not gcs_sync.configurado():
        log.info("  [gcs] GCS_BUCKET no configurado: los archivos quedan en staging/")
        return
    ruta = os.path.abspath(STAGING_DIR)
    if not os.path.isdir(ruta):
        log.info(f"  [gcs] No existe {ruta} — ¿estás en la carpeta correcta?")
        return
    n = sum(len(fs) for _, _, fs in os.walk(ruta))
    log.info(f"  [gcs] Subiendo {n} archivos desde {ruta} → gs://{os.getenv('GCS_BUCKET')}")
    ok, fail = gcs_sync.subir_y_limpiar(STAGING_DIR, STAGING_DIR)
    log.info(f"  [gcs] barrido staging: {ok} subidos · {fail} pendientes")


async def descargar_y_subir(df: pd.DataFrame, headless: bool | None = None):
    from playwright.async_api import async_playwright

    if df is None or df.empty:
        log.info("  Sin oportunidades para descargar")
        subir_pendientes()
        return

    gcs_ok    = gcs_sync.configurado()
    gcs_error = False
    filas     = df.to_dict("records")
    log.info(f"  Descargando documentos de {len(filas)} oportunidades"
             f" → {'GCS' if gcs_ok else 'solo staging local'}")

    async with async_playwright() as pw:
        browser, _, page = await abrir_navegador(pw, headless)
        await page.goto(BUSQUEDA_URL, wait_until="networkidle", timeout=30_000)
        await resolver_captcha(page)

        for i, row in enumerate(filas, 1):
            rel = ruta_proceso(row)
            log.info(f"  [{i}/{len(filas)}] {rel.split('raw/')[-1]}")
            meta_prev = None
            if gcs_ok:
                try:
                    meta_prev = gcs_sync.leer_json(f"{rel}/metadata.json")
                except Exception as e:
                    # Sin GCS igual se descarga; queda en staging y se sube después (--solo-subir)
                    if not gcs_error:
                        log.warning(f"    [gcs] no se pudo consultar el bucket ({e}). "
                                    f"Sigo descargando a staging/; revisa GOOGLE_CLOUD_PROJECT y GCS_BUCKET")
                    gcs_error = True
            try:
                meta = await descargar_proceso(page, row, meta_prev)
            except Exception as e:
                log.info(f"    ✗ {row.get('referencia')}: {e}")
                continue
            if meta and gcs_ok and not gcs_error:
                ok, fail = gcs_sync.subir_y_limpiar(carpeta_local(rel), STAGING_DIR)
                log.info(f"    [gcs] {ok} subidos · {fail} pendientes")

        await browser.close()

    if not gcs_error:
        subir_pendientes()


def oportunidades_abiertas() -> pd.DataFrame:
    from secop_reporte import CSV_MAESTRO, parsear_cierre
    if not os.path.exists(CSV_MAESTRO):
        return pd.DataFrame()
    df = pd.read_csv(CSV_MAESTRO, encoding="utf-8-sig", dtype={"referencia": str, "nit": str})
    ahora = pd.Timestamp.now(tz="America/Bogota")
    cierre = pd.to_datetime(df["fecha_limite"].apply(parsear_cierre), errors="coerce", utc=True)
    # Sin fecha parseable -> se trata como abierta (mismo criterio del reporte)
    return df[cierre.isna() | (cierre >= ahora)].reset_index(drop=True)


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # raíz del proyecto
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s",
                        datefmt="%H:%M:%S", handlers=[logging.StreamHandler(sys.stdout)])

    ap = argparse.ArgumentParser()
    ap.add_argument("--abiertas", action="store_true", help="re-visitar oportunidades abiertas (adendas)")
    ap.add_argument("--solo-subir", action="store_true", help="solo subir lo pendiente en staging")
    ap.add_argument("--limite", type=int, default=None, help="máximo de procesos (para pruebas)")
    ap.add_argument("--ref", default=None, help="filtra por texto en la referencia o la entidad")
    args = ap.parse_args()

    if args.solo_subir:
        subir_pendientes()
    elif args.abiertas:
        df = oportunidades_abiertas()
        if args.ref and not df.empty:
            txt = (df.get("referencia", "").astype(str) + " " + df.get("entidad", "").astype(str)).str.upper()
            df = df[txt.str.contains(args.ref.upper(), regex=False)]
        if args.limite:
            df = df.head(args.limite)
        log.info(f"Oportunidades abiertas a procesar: {len(df)}")
        asyncio.run(descargar_y_subir(df))
    else:
        ap.print_help()
