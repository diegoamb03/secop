"""
SECOP II Scraper v4.0
- Búsqueda 100% Playwright (click "Ver más")
- Descarga de documentos de oportunidades + subida a GCS (descargador.py)
- Checkpoint por tipo y por detalle
- Manifests JSON con documentFileId + nombre real (ref__fileId.pdf)
- Filtrado automático con transform.py (DuckDB)
- Reporte HTML con secop_reporte.py
"""

import asyncio
import json
import logging
import os
import re
import sys
import time
from datetime import datetime, timedelta

import pandas as pd
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright
import capsolver
# Raíz del proyecto = carpeta que contiene local/. Todo (staging, files_output, logs,
# _checkpoints) vive ahí, sin importar desde dónde se lance el script (VS Code, terminal,
# Programador de tareas).
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(PROJECT_ROOT)

from transform import filtrar, exportar_oportunidades, CSV_MAESTRO
from secop_reporte import generar_reporte_desde_csv, REPORTE_PATH
import gcs_sync
from descargador import descargar_y_subir, GCS_PREFIX

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# ══════════════════════════════════════════════════════════════════════
# CONFIGURACIÓN
# ══════════════════════════════════════════════════════════════════════
CAPSOLVER_API_KEY = os.getenv("CAPSOLVER_API_KEY", "")   # en .env, nunca en el código
HEADLESS          = os.getenv("HEADLESS", "false").lower() == "true"
SECOP_SITE_KEY    = "6LcMmakZAAAAAB157Q90hORUGtNd790TCws4vBNw"
BASE_URL          = "https://community.secop.gov.co"
DELAY_BUSQUEDA    = 1.2
DELAY_DETALLE     = 1.0

LOGS_DIR     = "logs"
OUTPUT_DIR   = "files_output"
HTML_DIR     = os.path.join(OUTPUT_DIR, "html_licitaciones")
PDF_DIR      = os.path.join(OUTPUT_DIR, "pdfs")
MANIFEST_DIR = os.path.join(OUTPUT_DIR, "manifests")
CKPT_DIR     = "_checkpoints"

for d in [LOGS_DIR, OUTPUT_DIR, HTML_DIR, PDF_DIR, MANIFEST_DIR, CKPT_DIR]:
    os.makedirs(d, exist_ok=True)

LOG_FILE    = os.path.join(LOGS_DIR, f"secop_{datetime.now().strftime('%Y%m%d_%H%M')}.log")
OUTPUT_FILE = os.path.join(OUTPUT_DIR, f"secop_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx")

def fmt_fecha(dt: datetime) -> str:
    return dt.strftime("%d/%m/%Y %I:%M %p")

ayer        = datetime.now() - timedelta(days=1)
FECHA_DESDE = fmt_fecha(ayer.replace(hour=0,  minute=0,  second=0))
FECHA_HASTA = fmt_fecha(ayer.replace(hour=23, minute=59, second=0))

TIPOS_PROCESO = [
    "CCE-02-Licitacion_Publica",
    "CCE-06-Seleccion_Abreviada_Menor_Cuantia",
    "CCE-10-Minima_Cuantia",
    "CCE-07-Seleccion_Abreviada_Subasta",
]

ESTADO      = ""
REGION      = ""
DESCRIPCION = ""

TIPO_LABELS = {
    "CCE-02-Licitacion_Publica":                "Licitacion_publica",
    "CCE-06-Seleccion_Abreviada_Menor_Cuantia": "Seleccion_abreviada",
    "CCE-10-Minima_Cuantia":                    "Minima_cuantia",
    "CCE-07-Seleccion_Abreviada_Subasta":       "CCE-07-Seleccion_Abreviada_Subasta",
    "CCE-16-Servicios_profesionales_gestion":   "Contratacion_directa",
    "":                                         "Todos",
}

# ── Logging ───────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(message)s",
    datefmt="%H:%M:%S",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ]
)
log = logging.getLogger()
_print = print
def print(*args, **kwargs):
    msg = " ".join(str(a) for a in args)
    if kwargs.get("end") == " ":
        _print(*args, **kwargs)
    else:
        log.info(msg)
        for h in log.handlers:
            h.flush()

PAT_DOC = re.compile(
    r"DownloadFile'\s*\+\s*'\?'\s*\+\s*'documentFileId='\s*\+\s*'(\d+)'",
    re.I
)
# ══════════════════════════════════════════════════════════════════════


# ──────────────────────────────────────────────────────────────────────
# UTILIDADES
# ──────────────────────────────────────────────────────────────────────

def es_pagina_error(html: str) -> bool:
    soup = BeautifulSoup(html, "html.parser")
    for span in soup.find_all("span"):
        t = span.get_text(strip=True)
        if "expirado por inactividad" in t or "página ha expirado" in t:
            return True
    form = soup.find("form", id="frmMainForm")
    if form and "ErrorPage" in form.get("action", ""):
        return True
    return False


def extraer_notice_uid(fila_html: str) -> str:
    m = re.search(r"noticeUID.*?['\"]([A-Z0-9][A-Z0-9._-]+)['\"]", fila_html)
    if m:
        return (f"{BASE_URL}/Public/Tendering/OpportunityDetail/Index"
                f"?noticeUID={m.group(1)}&isFromPublicArea=True")
    m2 = re.search(r"windowURL:\s*'(/Public/Tendering/OpportunityDetail/[^']+)'", fila_html)
    if m2:
        return BASE_URL + m2.group(1)
    return ""


def parsear_cuantia(raw: str):
    if not raw:
        return None
    m = re.search(r"[\d][\d.,]+", raw.strip())
    if not m:
        return None
    num = m.group(0)
    if "," in num and "." in num:
        num = num.replace(".", "").replace(",", ".")
    elif "," in num:
        partes = num.split(",")
        num = num.replace(",", ".") if len(partes[-1]) == 2 else num.replace(",", "")
    else:
        partes = num.split(".")
        if len(partes) > 1 and all(len(p) == 3 for p in partes[1:]):
            num = num.replace(".", "")
    try:
        v = float(num)
        return v if v <= 50_000_000_000_000 else None
    except ValueError:
        return None


def limpiar_nombre(texto: str, max_len: int = 40) -> str:
    limpio = re.sub(r'[\\/:*?"<>|]', "_", str(texto))
    return re.sub(r"\s+", " ", limpio).strip()[:max_len]


def guardar_manifest(res: dict) -> str:
    ref_raw  = res.get("referencia", f"LIC_{res.get('idx', 0)}")
    ref_slug = limpiar_nombre(ref_raw, 60)
    ent_slug = limpiar_nombre(res.get("entidad", "SIN_ENTIDAD"), 40)
    path     = os.path.join(MANIFEST_DIR, f"{ent_slug}__{ref_slug}.json")

    # Nombre de archivo = referencia__fileId.pdf
    ref_prefix = limpiar_nombre(ref_raw, 50)
    docs = []
    for item in res.get("_doc_items", []):
        file_id = item["documentFileId"]
        nombre  = item.get("nombre") or f"{ref_prefix}__{file_id}.pdf"
        # Asegurar que el nombre tiene la referencia como prefijo
        if not nombre.startswith(ref_prefix[:20]):
            nombre = f"{ref_prefix}__{nombre}"
        nombre = limpiar_nombre(nombre, 120)
        if not re.search(r'\.(pdf|docx?|xlsx?|zip|rar)$', nombre, re.I):
            nombre += ".pdf"
        docs.append({
            "documentFileId": file_id,
            "url_base":       f"{BASE_URL}/Public/Tendering/OpportunityDetail/DownloadFile",
            "nombre":         nombre,
            "local":          None,
            "descargado":     False,
        })

    manifest = {
        "referencia":        res.get("referencia", ""),
        "entidad":           res.get("entidad", ""),
        "nit":               res.get("nit", ""),
        "objeto":            res.get("objeto", res.get("descripcion_detalle", "")),
        "tipo_proceso":      res.get("tipo_proceso", ""),
        "cuantia_cop":       res.get("cuantia_cop"),
        "moneda":            res.get("moneda", "COP"),
        "municipio":         res.get("municipio", ""),
        "departamento":      res.get("departamento", ""),
        "fecha_publicacion": res.get("fecha_publicacion", ""),
        "fecha_limite":      res.get("fecha_limite", ""),
        "url_detalle":       res.get("url_detalle", ""),
        "html_local":        res.get("ruta_html"),
        "num_documentos":    len(docs),
        "documentos":        docs,
        "error":             res.get("error"),
        "extraido_en":       datetime.now().isoformat(),
    }

    with open(path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    return path


# ──────────────────────────────────────────────────────────────────────
# BÚSQUEDA
# ──────────────────────────────────────────────────────────────────────

def parsear_resultados(html: str, pagina: int, urls_vistas: set) -> tuple[list[dict], bool]:
    if es_pagina_error(html):
        raise RuntimeError("Sesión expirada")

    soup  = BeautifulSoup(html, "html.parser")
    tabla = soup.find("table", class_="VortalGrid")

    if not tabla:
        with open(f"_debug_pag{pagina}.html", "w", encoding="utf-8") as f:
            f.write(html[:6000])
        return [], False

    if tabla.find("td", class_="VortalGridEmptyResult"):
        return [], False

    licitaciones = []
    for fila in tabla.find_all("tr")[1:]:
        celdas = fila.find_all("td")
        if len(celdas) < 8:
            continue
        licitaciones.append({
            "pais":              celdas[0].get_text(" ", strip=True),
            "entidad":           celdas[1].get_text(" ", strip=True),
            "referencia":        celdas[2].get_text(" ", strip=True),
            "descripcion":       celdas[3].get_text(" ", strip=True),
            "fase_actual":       celdas[4].get_text(" ", strip=True),
            "fecha_publicacion": celdas[5].get_text(" ", strip=True),
            "fecha_limite":      celdas[6].get_text(" ", strip=True),
            "cuantia_raw":       celdas[7].get_text(" ", strip=True),
            "estado":            celdas[8].get_text(" ", strip=True) if len(celdas) > 8 else "",
            "url_detalle":       extraer_notice_uid(str(fila)),
        })

    if pagina == 1:
        ok = sum(1 for l in licitaciones if l["url_detalle"])
        print(f"         [urls] {ok}/{len(licitaciones)}")

    urls_pagina = {l["url_detalle"] for l in licitaciones if l["url_detalle"]}
    if urls_pagina and urls_pagina.issubset(urls_vistas):
        return [], False
    urls_vistas.update(urls_pagina)

    hay_mas = False
    td_mas  = soup.find("td", class_="VortalPaginatorMorePages")
    if td_mas and td_mas.find("a"):
        hay_mas = bool(td_mas.find("a").get_text(strip=True))

    return licitaciones, hay_mas


async def buscar_tipo_playwright(page, tipo: str) -> list[dict]:
    todas       = []
    pagina      = 1
    urls_vistas = set()

    print(f"    [filtros] región={REGION or 'todas'} | {FECHA_DESDE} → {FECHA_HASTA}")

    try:
        await page.wait_for_selector("#btnSearchButton", timeout=15_000)
        if tipo:
            await page.select_option("#selProcedureType", value=tipo)
            await asyncio.sleep(0.3)
        await page.locator("#txtRegion").fill("")
        if REGION:
            await page.locator("#txtRegion").fill(REGION)
        await page.evaluate(f"""
            var desde = document.getElementById('dtmbPublishDateFrom_txt');
            var hasta  = document.getElementById('dtmbPublishDateTo_txt');
            if(desde) desde.value = '{FECHA_DESDE}';
            if(hasta)  hasta.value  = '{FECHA_HASTA}';
        """)
        await asyncio.sleep(0.3)
        if ESTADO:
            await page.select_option("#selRequestStatus", value=ESTADO)
        await page.click("#btnSearchButton")
        await page.wait_for_load_state("networkidle", timeout=20_000)
        await asyncio.sleep(1.5)
    except Exception as e:
        print(f"    [!] Error en formulario: {e}")
        return []

    while True:
        html = await page.content()
        if es_pagina_error(html):
            print(f"    [!] Sesión expirada en pág {pagina}")
            break
        try:
            licitaciones, hay_mas = parsear_resultados(html, pagina, urls_vistas)
        except RuntimeError:
            break
        if not licitaciones:
            if pagina == 1:
                print("    sin resultados")
            break
        todas.extend(licitaciones)
        print(f"    Pág {pagina}: {len(todas)} acum")
        if not hay_mas:
            break
        try:
            ver_mas = page.locator("td.VortalPaginatorMorePages a").first
            if await ver_mas.count() == 0:
                break
            await ver_mas.click()
            await page.wait_for_load_state("networkidle", timeout=15_000)
            await asyncio.sleep(DELAY_BUSQUEDA)
            pagina += 1
        except Exception as e:
            print(f"    [!] Error Ver más pág {pagina}: {e}")
            break

    return todas


async def buscar_todas(page) -> list[dict]:
    print(f"\n[2/7] Búsqueda: {FECHA_DESDE}  →  {FECHA_HASTA}")
    print(f"      Tipos: {len(TIPOS_PROCESO)}")

    fecha_clave = FECHA_DESDE[:8].replace("/", "")
    todas       = []
    refs_vistas = set()

    for tipo in TIPOS_PROCESO:
        label     = TIPO_LABELS.get(tipo, tipo)
        ckpt_file = os.path.join(CKPT_DIR, f"{fecha_clave}_{label}.xlsx")

        if os.path.exists(ckpt_file):
            print(f"\n  ── {label} ── [checkpoint]")
            lics = pd.read_excel(ckpt_file).to_dict("records")
            print(f"    Retomado: {len(lics)} licitaciones")
        else:
            print(f"\n  ── {label} ──")
            await page.goto(
                f"{BASE_URL}/Public/Tendering/ContractNoticeManagement/Index"
                "?currentLanguage=es-CO&Page=login&Country=CO&SkinName=CCE",
                wait_until="networkidle", timeout=20_000
            )
            await asyncio.sleep(1)
            lics = await buscar_tipo_playwright(page, tipo)
            for l in lics:
                l["tipo_filtro"] = label
            if lics:
                pd.DataFrame(lics).to_excel(ckpt_file, index=False)
                print(f"    [ckpt] {ckpt_file} ({len(lics)} filas)")

        for lic in lics:
            ref = lic.get("referencia", "")
            if ref not in refs_vistas:
                refs_vistas.add(ref)
                todas.append(lic)

    print(f"\n  Total único: {len(todas)}")
    return todas


# ──────────────────────────────────────────────────────────────────────
# DETALLE
# ──────────────────────────────────────────────────────────────────────

CAMPO_MAP = {
    "número del proceso":      "numero_proceso",
    "entidad estatal":         "entidad_detalle",
    "nit":                     "nit",
    "descripción":             "descripcion_detalle",
    "objeto del proceso":      "objeto",
    "objeto del contrato":     "objeto",
    "tipo de proceso":         "tipo_proceso",
    "modalidad de selección":  "modalidad",
    "estado":                  "estado_detalle",
    "fase actual":             "fase_detalle",
    "región":                  "region",
    "departamento":            "departamento",
    "municipio":               "municipio",
    "lugar de ejecución":      "lugar_ejecucion",
    "cuantía":                 "cuantia_texto",
    "presupuesto oficial":     "presupuesto",
    "valor del contrato":      "valor_contrato",
    "moneda":                  "moneda",
    "forma de pago":           "forma_pago",
    "fuente de financiación":  "fuente_financiacion",
    "duración del contrato":   "duracion",
    "plazo de ejecución":      "plazo_ejecucion",
    "fecha de publicación":    "fecha_pub_detalle",
    "fecha de presentación":   "fecha_presentacion",
    "fecha de apertura":       "fecha_apertura",
    "fecha de adjudicación":   "fecha_adjudicacion",
    "fecha estimada de firma":  "fecha_firma",
    "código unspsc":           "unspsc",
    "número de oferentes":     "num_oferentes",
    "oferente adjudicado":     "adjudicado",
    "contratista":             "contratista",
    "valor adjudicado":        "valor_adjudicado",
    "nombre del responsable":  "responsable",
    "correo electrónico":      "email_entidad",
}

CAMPOS_CORTOS = {
    "tipo_proceso", "modalidad", "estado_detalle", "fase_detalle",
    "region", "departamento", "municipio", "moneda", "forma_pago",
    "duracion", "unspsc",
}

ID_MAP = {
    "cbxBasePriceValue":    "cuantia_texto",
    "spnRequestReference":  "numero_proceso",
    "spnRequestName":       "descripcion_detalle",
    "spnProcedureType":     "tipo_proceso",
    "spnCurrentPhaseCode":  "fase_detalle",
    "spnRegion":            "region",
    "spnNuts":              "departamento",
    "spnMunicipality":      "municipio",
    "spnCurrency":          "moneda",
    "spnDuration":          "duracion",
    "spnOpeningDate":       "fecha_apertura",
    "spnPublishDate":       "fecha_pub_detalle",
    "spnDeadline":          "fecha_presentacion",
    "spnAwardDate":         "fecha_adjudicacion",
    "spnMainCategory":      "unspsc",
    "spnNumberOfTenders":   "num_oferentes",
    "spnAwardedTender":     "adjudicado",
    "spnContactName":       "responsable",
    "spnContactEmail":      "email_entidad",
    "spnRequestObjective":  "objeto",
    "spnPaymentConditions": "forma_pago",
}


async def extraer_detalle(page, lic: dict, idx: int) -> dict:
    url = lic.get("url_detalle", "")
    res = dict(lic)
    res["_doc_items"] = []

    if not url or "javascript" in url:
        res["error"] = "url_invalida"
        print(f"  ✗ Sin URL: {lic.get('referencia','?')}")
        res["ruta_manifest"] = guardar_manifest(res)
        return res

    MAX_INTENTOS = 3

    for intento in range(1, MAX_INTENTOS + 1):
        try:
            await page.goto(url, wait_until="networkidle", timeout=25_000)
            await asyncio.sleep(1.5)
            html = await page.content()

            tiene_captcha = (
                "GoogleReCaptcha" in page.url
                or await page.locator("#divGoogleReCaptcha").count() > 0
                or ("g-recaptcha" in html and "onSubmit" in html)
            )

            if tiene_captcha:
                print(f"\n  [captcha] {'Resolviendo' if intento == 1 else f'Reintento {intento}'} en detalle #{idx}...")
                capsolver.api_key = CAPSOLVER_API_KEY
                sol = capsolver.solve({
                    "type":       "ReCaptchaV2TaskProxyless",
                    "websiteURL": page.url,
                    "websiteKey": SECOP_SITE_KEY,
                })
                token = sol["gRecaptchaResponse"]
                await page.evaluate(f"""
                    document.getElementById('g-recaptcha-response').value = '{token}';
                    document.getElementById('txaresponseKey').value = '{token}';
                    onSubmit();
                """)
                await page.wait_for_load_state("networkidle", timeout=20_000)
                await asyncio.sleep(2)
                html = await page.content()

            if "g-recaptcha" in html and "onSubmit" in html:
                if intento < MAX_INTENTOS:
                    await asyncio.sleep(3 * intento)
                    continue
                res["error"] = "captcha_persistente"
                print(f"  ✗ Captcha persistente en #{idx}")
                res["ruta_manifest"] = guardar_manifest(res)
                return res

            if es_pagina_error(html):
                if intento < MAX_INTENTOS:
                    await asyncio.sleep(2)
                    continue
                res["error"] = "sesion_expirada"
                res["ruta_manifest"] = guardar_manifest(res)
                return res

            # ── HTML válido ────────────────────────────────────────
            entidad = limpiar_nombre(lic.get("entidad", "SIN_ENTIDAD"))
            ref     = limpiar_nombre(lic.get("referencia", f"LIC_{idx}"), 50)
            carpeta = os.path.join(HTML_DIR, entidad)
            try:
                os.makedirs(carpeta, exist_ok=True)
                ruta = os.path.join(carpeta, f"{ref}.html")
                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(html)
                res["ruta_html"] = ruta
            except OSError:
                fb = os.path.join(HTML_DIR, f"empresa_{idx:05d}")
                os.makedirs(fb, exist_ok=True)
                ruta = os.path.join(fb, f"{idx:05d}_{ref}.html")
                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(html)
                res["ruta_html"] = ruta

            soup = BeautifulSoup(html, "html.parser")

            # Extraer campos por span ID
            for span in soup.find_all("span"):
                sid = span.get("id", "")
                for key_id, campo in ID_MAP.items():
                    if key_id.lower() in sid.lower() and campo not in res:
                        v = span.get_text(" ", strip=True)
                        if v:
                            res[campo] = v
                        break

            # Fallback: pares label/valor en tablas
            for tr in soup.find_all("tr"):
                celdas = tr.find_all("td")
                if len(celdas) >= 2:
                    label = celdas[0].get_text(" ", strip=True).lower().rstrip(":").strip()
                    valor = celdas[1].get_text(" ", strip=True)
                    if valor:
                        for key, campo in CAMPO_MAP.items():
                            if key in label and campo not in res:
                                max_l = 100 if campo in CAMPOS_CORTOS else 2000
                                if len(valor) <= max_l:
                                    res[campo] = valor
                                break

            # ── Documentos: extraer fileId + nombre real desde la fila ──
            ref_prefix = limpiar_nombre(res.get("referencia", f"LIC_{idx}"), 50)
            doc_items  = []
            vistos     = set()

            for tag in soup.find_all(onclick=True):
                m = PAT_DOC.search(tag.get("onclick", ""))
                if m:
                    file_id = m.group(1)
                    if file_id in vistos:
                        continue
                    vistos.add(file_id)

                    # Nombre real desde la primera celda del tr padre
                    nombre = f"{ref_prefix}__{file_id}.pdf"  # fallback
                    parent_tr = tag.find_parent("tr")
                    if parent_tr:
                        celdas_doc = parent_tr.find_all("td")
                        if celdas_doc:
                            nombre_raw = celdas_doc[0].get_text(" ", strip=True)
                            if nombre_raw:
                                nombre = f"{ref_prefix}__{limpiar_nombre(nombre_raw, 80)}"
                                if not re.search(r'\.(pdf|docx?|xlsx?|zip|rar)$', nombre, re.I):
                                    nombre += ".pdf"

                    doc_items.append({
                        "documentFileId": file_id,
                        "nombre":         nombre,
                    })

            res["_doc_items"]     = doc_items
            res["num_documentos"] = len(doc_items)
            res["docs_urls"]      = " | ".join(d["documentFileId"] for d in doc_items)

            # Cuantía numérica
            raw = res.get("cuantia_texto") or res.get("presupuesto") or res.get("cuantia_raw", "")
            res["cuantia_cop"] = parsear_cuantia(raw)

            # Guardar manifest
            res["ruta_manifest"] = guardar_manifest(res)

            ref_s  = res.get("referencia", "")[:28]
            ent_s  = res.get("entidad", "")[:35]
            val    = res.get("cuantia_cop")
            ndocs  = res["num_documentos"]
            vs     = f"COP {val:>18,.0f}" if val else "       sin cuantía"
            print(f"  ✓ {ref_s:<28} {ent_s:<35} {vs}  [{ndocs} docs]")
            return res

        except RuntimeError:
            raise
        except Exception as e:
            print(f"  ✗ Intento {intento}/{MAX_INTENTOS} — {url[-50:]}: {e}")
            if intento < MAX_INTENTOS:
                await asyncio.sleep(2 * intento)
            else:
                res["error"] = str(e)
                res["ruta_manifest"] = guardar_manifest(res)

    return res


# ──────────────────────────────────────────────────────────────────────
# EXPORTAR
# ──────────────────────────────────────────────────────────────────────

COLS = [
    "referencia", "entidad", "entidad_detalle", "nit",
    "descripcion", "descripcion_detalle", "objeto",
    "tipo_proceso", "modalidad", "estado", "estado_detalle", "fase_actual", "fase_detalle",
    "region", "departamento", "municipio", "lugar_ejecucion",
    "cuantia_cop", "cuantia_raw", "cuantia_texto", "presupuesto", "valor_contrato",
    "moneda", "forma_pago", "fuente_financiacion", "duracion", "plazo_ejecucion",
    "fecha_publicacion", "fecha_pub_detalle", "fecha_limite",
    "fecha_presentacion", "fecha_apertura", "fecha_adjudicacion", "fecha_firma",
    "unspsc", "num_oferentes", "adjudicado", "contratista", "valor_adjudicado",
    "responsable", "email_entidad", "num_documentos", "docs_urls",
    "url_detalle", "ruta_html", "ruta_manifest", "tipo_filtro", "pais", "error",
]


def exportar(df: pd.DataFrame, path: str):
    cols = [c for c in COLS if c in df.columns] + [c for c in df.columns if c not in COLS]
    # Quitar columna interna
    cols = [c for c in cols if c != "_doc_items"]
    df   = df[[c for c in cols if c in df.columns]]

    with pd.ExcelWriter(path, engine="openpyxl") as w:

        df.to_excel(w, sheet_name="Licitaciones", index=False)

        cop = df["cuantia_cop"] if "cuantia_cop" in df.columns else pd.Series(dtype=float)
        pd.DataFrame({
            "Métrica": ["Total","Con cuantía","Cuantía total COP",
                        "Promedio COP","Mín COP","Máx COP",
                        "Entidades únicas","Fecha extracción","Período"],
            "Valor": [
                len(df), int(cop.notna().sum()),
                f"{cop.sum():,.0f}", f"{cop.mean():,.0f}",
                f"{cop.min():,.0f}", f"{cop.max():,.0f}",
                df["entidad"].nunique() if "entidad" in df.columns else "N/A",
                datetime.now().strftime("%Y-%m-%d %H:%M"),
                f"{FECHA_DESDE} → {FECHA_HASTA}",
            ],
        }).to_excel(w, sheet_name="Resumen", index=False)

        if "entidad" in df.columns and "cuantia_cop" in df.columns:
            (df.groupby("entidad")
               .agg(licitaciones=("referencia","count"),
                    cuantia_total=("cuantia_cop","sum"),
                    promedio=("cuantia_cop","mean"))
               .sort_values("cuantia_total", ascending=False)
               .reset_index()
               .to_excel(w, sheet_name="Por entidad", index=False))

        # Hoja Documentos — desde manifests
        filas_docs = []
        for _, row in df.iterrows():
            mp = row.get("ruta_manifest", "")
            if mp and os.path.exists(str(mp)):
                with open(mp, encoding="utf-8") as f:
                    m = json.load(f)
                for doc in m.get("documentos", []):
                    filas_docs.append({
                        "referencia":     row.get("referencia", ""),
                        "entidad":        row.get("entidad", ""),
                        "cuantia_cop":    row.get("cuantia_cop"),
                        "documentFileId": doc.get("documentFileId", ""),
                        "nombre":         doc.get("nombre", ""),
                        "url_base":       doc.get("url_base", ""),
                        "local":          doc.get("local"),
                        "descargado":     doc.get("descargado", False),
                    })
        if filas_docs:
            pd.DataFrame(filas_docs).to_excel(w, sheet_name="Documentos", index=False)

        if "error" in df.columns and df["error"].notna().any():
            df[df["error"].notna()][["referencia","url_detalle","error"]] \
              .to_excel(w, sheet_name="Errores", index=False)

    print(f"  Excel: {path}")


# ──────────────────────────────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────────────────────────────

async def main():
    t0 = time.time()
    print("=" * 65)
    print("SECOP II Scraper v3.8")
    print(f"Python : {sys.version.split()[0]}  |  {sys.platform}")
    print(f"Período: {FECHA_DESDE}  →  {FECHA_HASTA}")
    print("=" * 65)

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=HEADLESS,
            args=["--no-sandbox","--disable-blink-features=AutomationControlled"]
        )
        ctx = await browser.new_context(
            viewport={"width": 1280, "height": 900},
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            ),
            locale="es-CO",
            timezone_id="America/Bogota",
        )
        await ctx.add_init_script(
            "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
        )
        page = await ctx.new_page()

        # ── 1. Captcha ───────────────────────────────────────────────
        print("\n[1/7] Resolviendo captcha...")
        capsolver.api_key = CAPSOLVER_API_KEY
        target = (
            f"{BASE_URL}/Public/Tendering/ContractNoticeManagement/Index"
            "?currentLanguage=es-CO&Page=login&Country=CO&SkinName=CCE"
        )
        await page.goto(target, wait_until="networkidle", timeout=30_000)

        if "GoogleReCaptcha" in page.url or await page.locator("#divGoogleReCaptcha").count() > 0:
            print("  [captcha] Detectado, resolviendo...")
            sol   = capsolver.solve({
                "type":       "ReCaptchaV2TaskProxyless",
                "websiteURL": page.url,
                "websiteKey": SECOP_SITE_KEY,
            })
            token = sol["gRecaptchaResponse"]
            print(f"  [captcha] Token OK ({token[:30]}...)")
            await page.evaluate(f"""
                document.getElementById('g-recaptcha-response').value = '{token}';
                document.getElementById('txaresponseKey').value = '{token}';
                onSubmit();
            """)
            await page.wait_for_load_state("networkidle", timeout=20_000)
        else:
            print("  [captcha] Sin captcha")

        await page.wait_for_selector("#btnSearchButton", timeout=15_000)
        html_form = await page.content()
        mkey_m    = re.search(r"mkey=([a-f0-9_]{30,})", html_form)
        mkey      = mkey_m.group(1) if mkey_m else ""
        cookies   = {c["name"]: c["value"] for c in await ctx.cookies()}
        print(f"  [session] mkey = {mkey}")
        print(f"  [session] cookies = {list(cookies.keys())}")

        # ── 2. Búsqueda ──────────────────────────────────────────────
        basico = await buscar_todas(page)

        if not basico:
            print("\n[!] Sin resultados.")
            await browser.close()
            return

        ckpt_basico = os.path.join(CKPT_DIR, f"{datetime.now().strftime('%Y%m%d_%H%M')}_basico.xlsx")
        pd.DataFrame(basico).to_excel(ckpt_basico, index=False)
        print(f"  [ckpt] {ckpt_basico} ({len(basico)} filas)")

        # ── 3. Detalle ───────────────────────────────────────────────
        total = len(basico)
        print(f"\n[3/7] Detalle de {total} licitaciones...\n")

        fecha_clave = datetime.now().strftime("%Y%m%d")
        ckpt_det    = os.path.join(CKPT_DIR, f"{fecha_clave}_detalles.xlsx")

        if os.path.exists(ckpt_det):
            df_prev    = pd.read_excel(ckpt_det)
            refs_ok    = set(df_prev["referencia"].dropna().tolist())
            resultados = df_prev.to_dict("records")
            print(f"  [retomar] {len(resultados)} detalles previos")
        else:
            refs_ok    = set()
            resultados = []

        for i, lic in enumerate(basico, 1):
            ref = lic.get("referencia", "")
            if ref in refs_ok:
                continue
            print(f"[{i:>5}/{total}]", end=" ")
            det = await extraer_detalle(page, lic, i)
            # No guardar columna interna en el checkpoint
            det_clean = {k: v for k, v in det.items() if k != "_doc_items"}
            resultados.append(det_clean)
            refs_ok.add(ref)
            await asyncio.sleep(DELAY_DETALLE)

            if len(resultados) % 25 == 0:
                pd.DataFrame(resultados).to_excel(ckpt_det, index=False)
                t_min = (time.time() - t0) / 60
                print(f"  [ckpt] {len(resultados)}/{total} detalles | {t_min:.0f} min")

        await browser.close()

        # ── 4. Exportar ──────────────────────────────────────────────
        print(f"\n[4/7] Exportando Excel...")
        df = pd.DataFrame(resultados)
        exportar(df, OUTPUT_FILE)

        # ── 5. Filtrar oportunidades ──────────────────────────────────
        print(f"\n[5/7] Filtrando oportunidades ferretería...")
        ts_filtro     = datetime.now().strftime("%Y%m%d_%H%M")
        filtro_output = os.path.join(OUTPUT_DIR, f"oportunidades_{ts_filtro}.xlsx")
        result_filtro, total_filtro = filtrar(OUTPUT_FILE)
        maestro = exportar_oportunidades(result_filtro, total_filtro, filtro_output)

        # ── 6. Reporte HTML ───────────────────────────────────────────
        print(f"\n[6/7] Generando reporte HTML acumulado...")
        reporte_path = generar_reporte_desde_csv(REPORTE_PATH)

        # ── 7. Documentos → GCS ───────────────────────────────────────
        print(f"\n[7/7] Descargando documentos de oportunidades y subiendo a GCS...")
        try:
            await descargar_y_subir(result_filtro, headless=HEADLESS)
            if gcs_sync.configurado():
                # Reporte y CSV maestro se suben como copia (se conservan en local)
                gcs_sync.subir_archivo(REPORTE_PATH, f"{GCS_PREFIX}/reportes/reporte_oportunidades.html")
                gcs_sync.subir_archivo(CSV_MAESTRO, f"{GCS_PREFIX}/reportes/oportunidades.csv")
        except Exception as e:
            print(f"  [!] Error en descarga/subida (se reintenta en la próxima corrida): {e}")

        # ── Resumen final ─────────────────────────────────────────────
        t_total   = (time.time() - t0) / 60
        cop       = df["cuantia_cop"] if "cuantia_cop" in df.columns else pd.Series(dtype=float)
        cop_op    = result_filtro["cuantia_cop"] if "cuantia_cop" in result_filtro.columns else pd.Series(dtype=float)
        total_docs = int(df["num_documentos"].sum()) if "num_documentos" in df.columns else 0

        print(f"\n{'=' * 65}")
        print(f"COMPLETADO en {t_total:.0f} minutos")
        print(f"Licitaciones  : {len(df)}")
        print(f"Oportunidades : {len(result_filtro)} ({len(result_filtro)/len(df)*100:.1f}%)")
        print(f"Acumuladas    : {len(maestro)}")
        print(f"Docs indexados: {total_docs}")
        print(f"Cuantía total : COP {cop.sum():>20,.0f}")
        print(f"Oport. COP    : COP {cop_op.sum():>20,.0f}")
        print(f"Excel general : {OUTPUT_FILE}")
        print(f"Excel filtrado: {filtro_output}")
        print(f"Reporte HTML  : {reporte_path}")
        print(f"{'=' * 65}")


if __name__ == "__main__":
    asyncio.run(main())