"""
Sesión SECOP II compartida (navegador + captcha).
Lo usa descargador.py. La API key de CapSolver sale de la variable de entorno CAPSOLVER_API_KEY.
"""

import asyncio
import os

import capsolver
from bs4 import BeautifulSoup

BASE_URL       = "https://community.secop.gov.co"
SECOP_SITE_KEY = "6LcMmakZAAAAAB157Q90hORUGtNd790TCws4vBNw"
BUSQUEDA_URL   = (f"{BASE_URL}/Public/Tendering/ContractNoticeManagement/Index"
                  "?currentLanguage=es-CO&Page=login&Country=CO&SkinName=CCE")


def headless_por_defecto() -> bool:
    return os.getenv("HEADLESS", "false").lower() == "true"


async def abrir_navegador(pw, headless: bool | None = None):
    """Mismo perfil de navegador que main.py. Retorna (browser, ctx, page)."""
    if headless is None:
        headless = headless_por_defecto()
    browser = await pw.chromium.launch(
        headless=headless,
        args=["--no-sandbox", "--disable-blink-features=AutomationControlled"],
    )
    ctx = await browser.new_context(
        viewport={"width": 1280, "height": 900},
        user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"),
        locale="es-CO",
        timezone_id="America/Bogota",
        accept_downloads=True,
    )
    await ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined});")
    page = await ctx.new_page()
    return browser, ctx, page


async def hay_captcha(page) -> bool:
    if "GoogleReCaptcha" in page.url:
        return True
    if await page.locator("#divGoogleReCaptcha").count() > 0:
        return True
    html = await page.content()
    return "g-recaptcha" in html and "onSubmit" in html


async def resolver_captcha(page) -> bool:
    """Resuelve el reCAPTCHA si aparece. Retorna True si tuvo que resolverlo."""
    if not await hay_captcha(page):
        return False
    api_key = os.getenv("CAPSOLVER_API_KEY")
    if not api_key:
        raise RuntimeError("Falta la variable de entorno CAPSOLVER_API_KEY")
    capsolver.api_key = api_key
    # capsolver es bloqueante: se corre en un hilo para no congelar el event loop
    sol = await asyncio.to_thread(capsolver.solve, {
        "type":       "ReCaptchaV2TaskProxyless",
        "websiteURL": page.url,
        "websiteKey": SECOP_SITE_KEY,
    })
    token = sol["gRecaptchaResponse"]
    await page.evaluate(
        """t => {
            document.getElementById('g-recaptcha-response').value = t;
            document.getElementById('txaresponseKey').value = t;
            onSubmit();
        }""",
        token,
    )
    await page.wait_for_load_state("networkidle", timeout=20_000)
    await asyncio.sleep(1.5)
    return True


def es_pagina_error(html: str) -> bool:
    soup = BeautifulSoup(html, "html.parser")
    for span in soup.find_all("span"):
        t = span.get_text(strip=True)
        if "expirado por inactividad" in t or "página ha expirado" in t:
            return True
    form = soup.find("form", id="frmMainForm")
    return bool(form and "ErrorPage" in form.get("action", ""))
