"""
Reacomoda lo que ya está en staging/ a la estructura actual de rutas, sin volver a descargar.
- Carpetas:  entidad=sin-nit_x/proceso=ms-samc-015-2026-manifestacion...  ->  entidad=x/proceso=ms-samc-015-2026
- Extensión real de cada documento según su contenido (%PDF -> .pdf, etc.)
- Documentos que en realidad son HTML de error -> se marcan como error (se re-descargan luego)
- Reescribe metadata.json con las rutas nuevas

Uso:  python migrar_staging.py            (muestra lo que haría)
      python migrar_staging.py --aplicar  (lo hace)
"""

import argparse
import json
import os
import shutil

from descargador import STAGING_DIR, carpeta_local, ext_por_contenido, nombre_archivo, ruta_proceso


def migrar(aplicar: bool):
    metas = []
    for dirpath, _, files in os.walk(STAGING_DIR):
        if "metadata.json" in files:
            metas.append(os.path.join(dirpath, "metadata.json"))

    print(f"Staging: {os.path.abspath(STAGING_DIR)}")
    if not metas:
        print("No hay procesos ahí — ¿estás en la carpeta desde donde corriste la descarga?")
        return

    movidos = renombrados = errores_html = 0
    for mpath in metas:
        with open(mpath, encoding="utf-8") as f:
            meta = json.load(f)
        dir_viejo = os.path.dirname(mpath)
        rel_nuevo = ruta_proceso(meta)
        dir_nuevo = carpeta_local(rel_nuevo)
        mover = os.path.abspath(dir_viejo) != os.path.abspath(dir_nuevo)

        print(f"{'→' if mover else '='} {meta.get('referencia')}")
        if mover:
            print(f"    {os.path.relpath(dir_viejo, STAGING_DIR)}\n    {os.path.relpath(dir_nuevo, STAGING_DIR)}")

        docs_nuevos = []
        for d in meta.get("documentos", []):
            if d.get("estado") != "ok" or not d.get("archivo"):
                docs_nuevos.append(d)
                continue
            fname_viejo = d["archivo"].rsplit("/", 1)[-1]
            local_viejo = os.path.join(dir_viejo, "documentos", fname_viejo)
            if not os.path.exists(local_viejo):
                docs_nuevos.append({**d, "estado": "error", "motivo": "archivo no encontrado en staging"})
                continue
            with open(local_viejo, "rb") as f:
                body = f.read()

            if body[:15].lstrip().lower().startswith((b"<!doctype", b"<html")):
                errores_html += 1
                print(f"    ✗ {fname_viejo}: es HTML, se re-descargará")
                if aplicar:
                    os.remove(local_viejo)
                docs_nuevos.append({"documentFileId": d["documentFileId"],
                                    "nombre_original": d.get("nombre_original"),
                                    "estado": "error", "motivo": "SECOP devolvió HTML"})
                continue

            # Nombre original de SECOP (guardado en metadata) > nombre actual del archivo
            actual = fname_viejo.split("__", 1)[-1]
            fuente = d.get("nombre_original") or actual
            ext_actual = os.path.splitext(actual)[1]
            fname_nuevo = nombre_archivo(d["documentFileId"], fuente, d.get("content_type") or "",
                                         body, ext_respaldo=ext_actual)
            if fname_nuevo != fname_viejo:
                renombrados += 1
                print(f"    {fname_viejo} -> {fname_nuevo}")
            if aplicar and fname_nuevo != fname_viejo:
                os.rename(local_viejo, os.path.join(dir_viejo, "documentos", fname_nuevo))
            docs_nuevos.append({**d, "archivo": f"{rel_nuevo}/documentos/{fname_nuevo}"})

        if not aplicar:
            continue

        meta.update({
            "ruta_gcs":          rel_nuevo,
            "documentos":        docs_nuevos,
            "num_documentos":    len(docs_nuevos),
            "descarga_completa": all(x.get("estado") == "ok" for x in docs_nuevos),
        })
        with open(mpath, "w", encoding="utf-8") as f:
            f.write(json.dumps(meta, ensure_ascii=False))

        if mover:
            movidos += 1
            os.makedirs(dir_nuevo, exist_ok=True)
            for item in os.listdir(dir_viejo):
                origen, destino = os.path.join(dir_viejo, item), os.path.join(dir_nuevo, item)
                if os.path.isdir(origen) and os.path.isdir(destino):
                    for sub in os.listdir(origen):
                        shutil.move(os.path.join(origen, sub), os.path.join(destino, sub))
                    os.rmdir(origen)
                else:
                    shutil.move(origen, destino)
            # limpiar carpetas vacías que quedaron
            p = dir_viejo
            while os.path.abspath(p) != os.path.abspath(STAGING_DIR):
                try:
                    os.rmdir(p)
                except OSError:
                    break
                p = os.path.dirname(p)

    print(f"\n{len(metas)} procesos · {movidos if aplicar else '(simulación)'} movidos · "
          f"{renombrados} archivos renombrados · {errores_html} HTML de error")
    if not aplicar:
        print("Nada cambió. Si se ve bien:  python migrar_staging.py --aplicar")


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # raíz del proyecto
    ap = argparse.ArgumentParser()
    ap.add_argument("--aplicar", action="store_true")
    migrar(ap.parse_args().aplicar)
