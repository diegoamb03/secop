"""
SECOP Transform v3.0 — Ferretería
- Filtra por entidad (geo) + ACTIVIDADES ECONÓMICAS (config/filtros.json)
- Texto normalizado (sin tildes) y palabras completas (BOMBA ≠ BOMBILLO)
- Acumula oportunidades en CSV maestro con dedup por referencia
- Uso standalone : python transform.py <ruta_excel>
- Uso como módulo: from transform import filtrar, exportar_oportunidades
"""

import json, os, re, sys, unicodedata

import pandas as pd
from datetime import datetime

OUTPUT_DIR  = "files_output"
CSV_MAESTRO = os.path.join(OUTPUT_DIR, "oportunidades.csv")

# ── Configuración de filtros: config/filtros.json (editable sin tocar código) ──
FILTROS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config", "filtros.json")


def cargar_filtros(path: str = FILTROS_PATH) -> dict:
    with open(path, encoding="utf-8") as f:
        cfg = json.load(f)
    return {k: v for k, v in cfg.items() if not k.startswith("_")}


# ══════════════════════════════════════════════════════════════════════

def normalizar(texto) -> str:
    """MAYÚSCULAS, sin tildes, espacios simples: 'Tubería  PVC' -> 'TUBERIA PVC'."""
    if texto is None or (isinstance(texto, float) and texto != texto):
        return ""
    t = unicodedata.normalize("NFKD", str(texto)).encode("ascii", "ignore").decode()
    return re.sub(r"\s+", " ", t.upper()).strip()


def _patron_termino(termino: str, plural: bool = True, prefijo: bool = False) -> str:
    palabras = [re.escape(w) for w in normalizar(termino).split()]
    cuerpo = r"\s+".join(palabras)
    if prefijo:                       # exclusiones tipo FARMAC -> FARMACIA, FARMACEUTICO
        return cuerpo
    return cuerpo + (r"(?:ES|S)?" if plural else "") + r"\b"


def compilar(terminos, plural=True, prefijo=False) -> re.Pattern:
    alternativas = sorted({_patron_termino(t, plural, prefijo) for t in terminos}, key=len, reverse=True)
    return re.compile(r"\b(?:" + "|".join(alternativas) + ")")


def aplicar_filtros(df: pd.DataFrame, cfg: dict | None = None) -> tuple[pd.DataFrame, dict]:
    """
    Retorna (oportunidades, conteo del embudo).
    Columnas nuevas: region_detectada, actividades, num_actividades, keyword_detectada, es_obra.
    """
    cfg = cfg or cargar_filtros()
    n0 = len(df)
    df = df.copy()

    def col(nombre):
        return df[nombre].fillna("").astype(str) if nombre in df.columns \
            else pd.Series("", index=df.index)

    texto   = (col("descripcion") + " " + col("descripcion_detalle")).map(normalizar)
    entidad = col("entidad").map(normalizar)

    # 1) Geografía (sobre el nombre de la entidad)
    pat_region = {dep: compilar(terms, plural=False) for dep, terms in cfg["regiones"].items()}
    def region(e):
        for dep, pat in pat_region.items():
            if pat.search(e):
                return dep
        return None
    df["region_detectada"] = entidad.map(region)
    m_geo = df["region_detectada"].notna()

    # 2) Exclusiones
    m_excl = texto.map(lambda t: bool(compilar_cache("excl", cfg["exclusiones"], prefijo=True).search(t)))

    # 3) Actividades económicas (todas las que coincidan)
    pat_act = {nombre: compilar(terms) for nombre, terms in cfg["actividades"].items()}
    acts = texto.map(lambda t: [n for n, p in pat_act.items() if p.search(t)])
    df["actividades"]     = acts.map(lambda a: ", ".join(a))
    df["num_actividades"] = acts.map(len)
    df["keyword_detectada"] = acts.map(lambda a: a[0] if a else None)  # compatibilidad con el reporte
    m_act = df["num_actividades"] > 0

    # 4) Obras (se marcan; se excluyen solo si incluir_obras = false)
    pat_obra = compilar(cfg.get("marcadores_obra", []), plural=False)
    df["es_obra"] = texto.map(lambda t: bool(pat_obra.search(t)))
    m_obra = df["es_obra"] if not cfg.get("incluir_obras", True) else pd.Series(False, index=df.index)

    # 5) Cuantía mínima
    cmin = cfg.get("cuantia_min", 0) or 0
    cuantia = pd.to_numeric(df.get("cuantia_cop"), errors="coerce") if "cuantia_cop" in df.columns \
        else pd.Series(float("nan"), index=df.index)
    m_cuantia = cuantia.isna() | (cuantia >= cmin)

    final = m_geo & m_act & ~m_excl & ~m_obra & m_cuantia
    embudo = {
        "total":               n0,
        "en_region":           int(m_geo.sum()),
        "region+actividad":    int((m_geo & m_act).sum()),
        "excluidas":           int((m_geo & m_act & m_excl).sum()),
        "obras_descartadas":   int((m_geo & m_act & ~m_excl & m_obra).sum()),
        "oportunidades":       int(final.sum()),
    }
    out = df[final].copy()
    out["_cuantia"] = cuantia[final]
    out = (out.sort_values(["num_actividades", "_cuantia"], ascending=[False, False], na_position="last")
              .drop(columns="_cuantia").reset_index(drop=True))
    return out, embudo


_CACHE = {}
def compilar_cache(clave, terminos, **kw):
    k = (clave, tuple(terminos), tuple(sorted(kw.items())))
    if k not in _CACHE:
        _CACHE[k] = compilar(terminos, **kw)
    return _CACHE[k]


def filtrar(input_path: str):
    """Lee el Excel de licitaciones y retorna (DataFrame filtrado, total_input)."""
    print(f"  Leyendo: {input_path}")
    try:
        df = pd.read_excel(input_path, sheet_name="Licitaciones")
    except ValueError:
        df = pd.read_excel(input_path)
    print(f"  Filas cargadas: {len(df)}")

    cols_ok = [c for c in [
        "referencia","entidad","descripcion","descripcion_detalle",
        "cuantia_cop","cuantia_raw","fecha_publicacion","fecha_limite",
        "fase_actual","estado","tipo_proceso","tipo_filtro",
        "num_documentos","url_detalle",
        "nit","docs_urls","ruta_manifest",
    ] if c in df.columns]

    result, embudo = aplicar_filtros(df[cols_ok])
    print("  Embudo: " + " → ".join(f"{k} {v}" for k, v in embudo.items()))
    # Identificador único real del proceso en SECOP (la referencia se repite entre entidades)
    result["notice_uid"] = _notice_uid(result)
    return result, len(df)


def _notice_uid(df: pd.DataFrame) -> pd.Series:
    if "url_detalle" not in df.columns:
        return pd.Series(pd.NA, index=df.index, dtype="object")
    return df["url_detalle"].astype(str).str.extract(r"noticeUID=([^&]+)", expand=False)


def _llave(df: pd.DataFrame) -> pd.Series:
    """notice_uid; si no hay, referencia|entidad (LP-005-2026 existe en cientos de municipios)."""
    uid = df["notice_uid"] if "notice_uid" in df.columns else pd.Series(pd.NA, index=df.index, dtype="object")
    uid = uid.where(uid.notna() & (uid.astype(str).str.strip() != ""), _notice_uid(df))
    ref = df["referencia"].astype(str) if "referencia" in df.columns else ""
    ent = df["entidad"].astype(str) if "entidad" in df.columns else ""
    return uid.fillna(ref + "|" + ent)


def actualizar_csv_maestro(result: pd.DataFrame) -> pd.DataFrame:
    """
    Hace append al CSV maestro y deduplica por notice_uid (fallback referencia|entidad).
    Gana la versión NUEVA (la de esta corrida) sobre la existente.
    - Alinea columnas por nombre (tolera cambios de esquema entre corridas).
    - Conserva fecha_captura: el día en que la oportunidad entró por primera vez.
    """
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    hoy = datetime.now().strftime("%Y-%m-%d")

    nuevas = result.copy()
    nuevas["_llave"] = _llave(nuevas)
    nuevas["fecha_captura"] = hoy

    if os.path.exists(CSV_MAESTRO) and os.path.getsize(CSV_MAESTRO) > 0:
        existente = pd.read_csv(CSV_MAESTRO, encoding="utf-8-sig",
                                dtype={"referencia": str, "nit": str, "notice_uid": str})
        existente["_llave"] = _llave(existente)

        # Mantener la fecha de primera captura para las que ya existían
        if "fecha_captura" in existente.columns:
            primera = (existente.drop_duplicates("_llave")
                                .set_index("_llave")["fecha_captura"].to_dict())
            nuevas["fecha_captura"] = nuevas["_llave"].map(primera).fillna(hoy)

        # nuevas primero -> keep="first" hace que gane la versión más reciente
        maestro = (pd.concat([nuevas, existente], ignore_index=True, sort=False)
                     .drop_duplicates(subset="_llave", keep="first"))
    else:
        maestro = nuevas

    maestro["notice_uid"] = maestro["_llave"].where(~maestro["_llave"].astype(str).str.contains(r"\|"))
    maestro = maestro.drop(columns=["_llave"])

    if "cuantia_cop" in maestro.columns:
        maestro["cuantia_cop"] = pd.to_numeric(maestro["cuantia_cop"], errors="coerce")
        maestro = maestro.sort_values("cuantia_cop", ascending=False, na_position="last")

    maestro = maestro.reset_index(drop=True)
    maestro.to_csv(CSV_MAESTRO, index=False, encoding="utf-8-sig")
    print(f"  CSV maestro: {CSV_MAESTRO} ({len(maestro)} oportunidades acumuladas)")
    return maestro


def exportar_oportunidades(result: pd.DataFrame, total_input: int, output_path: str):
    """Exporta Excel de oportunidades del día Y actualiza el CSV maestro."""
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    cop = result["cuantia_cop"] if "cuantia_cop" in result.columns else pd.Series(dtype=float)

    with pd.ExcelWriter(output_path, engine="openpyxl") as w:

        result.to_excel(w, sheet_name="Oportunidades", index=False)

        pd.DataFrame({
            "Métrica": [
                "Total procesadas","Oportunidades","Tasa de conversión",
                "Cuantía total COP","Promedio COP","Máx COP","Mín COP",
                "Entidades únicas","Fecha filtrado",
            ],
            "Valor": [
                total_input, len(result),
                f"{len(result)/total_input*100:.1f}%" if total_input else "0%",
                f"{cop.sum():,.0f}", f"{cop.mean():,.0f}",
                f"{cop.max():,.0f}", f"{cop.min():,.0f}",
                result["entidad"].nunique() if "entidad" in result.columns else 0,
                datetime.now().strftime("%Y-%m-%d %H:%M"),
            ],
        }).to_excel(w, sheet_name="Resumen", index=False)

        (result.groupby("region_detectada")
         .agg(licitaciones=("referencia","count"), cuantia_total=("cuantia_cop","sum"))
         .sort_values("cuantia_total", ascending=False).reset_index()
         .to_excel(w, sheet_name="Por region", index=False))

        (result.groupby("keyword_detectada")
         .agg(licitaciones=("referencia","count"), cuantia_total=("cuantia_cop","sum"))
         .sort_values("licitaciones", ascending=False).reset_index()
         .to_excel(w, sheet_name="Por keyword", index=False))

    print(f"  Excel día   : {output_path}")

    # Actualizar CSV maestro
    maestro = actualizar_csv_maestro(result)

    print(f"\n{'='*55}")
    print(f"FILTRADO COMPLETADO")
    print(f"Total procesadas     : {total_input}")
    print(f"Oportunidades hoy    : {len(result)}")
    print(f"Acumulado en CSV     : {len(maestro)}")
    print(f"Cuantía total COP    : {cop.sum():>20,.0f}")
    print(f"{'='*55}\n")

    return maestro


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python transform.py <ruta_excel>")
        sys.exit(1)

    ts          = datetime.now().strftime("%Y%m%d_%H%M")
    output_path = os.path.join(OUTPUT_DIR, f"oportunidades_{ts}.xlsx")
    result, total = filtrar(sys.argv[1])
    exportar_oportunidades(result, total, output_path)