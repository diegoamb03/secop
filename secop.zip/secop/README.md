# SECOP II — Oportunidades y análisis de cumplimiento

```
PC local (IP residencial, navegador con ventana)            GCP
────────────────────────────────────────────                ─────────────────────────────────────────
main.py      búsqueda + detalle + filtro + reporte HTML
  └─ descargador.py  PDFs de las oportunidades  ──(verifica MD5, borra local)──►  gs://BUCKET/secop/raw/...
                                                                                     │
                                          Cloud Scheduler 9:00 ─► Cloud Run Job "secop-analizador"
                                                                     Gemini EXTRAE requisitos (con cita)
                                                                     evaluador.py DECIDE (reglas fijas)
                                                                                     ▼
                                                              gs://BUCKET/secop/analisis/...  ─► BigQuery
```

## Estructura del bucket

```
secop/
  config/perfil_empresa.json                          ← datos del RUP de la empresa
  raw/entidad=<entidad>/proceso=<referencia>/
      metadata.json · detalle.html · documentos/<fileId>__<nombre>.pdf
  analisis/entidad=<entidad>/proceso=<referencia>/analisis.json
  reportes/reporte_oportunidades.html · oportunidades.csv
```

## 1. GCP (una vez)

1. Crea una API key de Gemini en https://aistudio.google.com/apikey
2. Copia `gcp/perfil_empresa.ejemplo.json` → `gcp/perfil_empresa.json` y llénalo con el RUP real
   (incluye `smmlv_vigente`).
3. Desde Cloud Shell:
   ```bash
   PROJECT_ID=tu-proyecto BUCKET=tu-bucket-secop GEMINI_API_KEY=xxx bash gcp/setup_gcp.sh
   ```
4. Crea una alerta de presupuesto (Billing → Budgets & alerts). Avisa, no corta el gasto.

Si cambia el RUP: `gcloud storage cp gcp/perfil_empresa.json gs://BUCKET/secop/config/perfil_empresa.json`.
No hay que redesplegar. Para re-evaluar todo con el perfil nuevo, borra `secop/analisis/`.

## 2. PC local (una vez)

```powershell
pip install -r local/requirements.txt
playwright install chromium
gcloud auth application-default login      # credenciales para subir a GCS, sin archivos de llaves
gcloud auth application-default set-quota-project TU_PROYECTO
copy local\.env.example local\.env          # y llénalo (CapSolver con key NUEVA)
```

Programador de tareas de Windows → tarea diaria 6:00 a. m.:
- Programa: `python`   · Argumentos: `main.py`   · Iniciar en: `C:\...\local`
- Marca "Ejecutar tanto si el usuario inició sesión como si no" y evita que el PC se suspenda.

Tarea opcional para adendas (p. ej. 2:00 p. m.): `python descargador.py --abiertas`

## 3. Consultar resultados

```sql
SELECT * FROM `PROYECTO.secop.oportunidades_evaluadas`;           -- qué puedo presentar
SELECT * FROM `PROYECTO.secop.checks` WHERE referencia = 'LP-005-2026';  -- por qué sí / por qué no
```

Ejecutar el analizador a mano: `gcloud run jobs execute secop-analizador --region us-central1 --wait`

## Estados

| Estado | Significa |
|---|---|
| CUMPLE | Todos los requisitos cuantitativos (RUP, indicadores, experiencia) se cumplen |
| NO_CUMPLE | Al menos uno falla — el resumen dice cuál y por cuánto |
| REVISAR | Falta un dato (en el pliego o en el perfil) o el pliego es ambiguo |

`pendientes_manual` lista lo cualitativo (certificaciones, visita obligatoria, garantías, personal):
no cambia el estado global pero hay que revisarlo antes de presentar.

**Es un filtro, no un concepto jurídico.** Antes de presentar una oferta, verifica los checks contra
la cita y página que trae cada uno.

## Variables del Job

| Variable | Default | Para qué |
|---|---|---|
| `MAX_PROCESOS` | 20 | Procesos por corrida (controla costo / límites de la API) |
| `MAX_DOCS` | 6 | PDFs por proceso (prioriza pliego, adendas, estudios previos) |
| `MAX_MB_TOTAL` | 45 | Tope de MB por proceso |
| `GEMINI_MODEL` | gemini-2.5-flash | Verifica el modelo vigente en la doc de Google |
| `GEMINI_BACKEND` | api | `vertex` para usar Vertex AI con la cuenta de servicio |

## Tests

```bash
python -m pytest gcp/tests -q
```
