-- setup_gcp.sh reemplaza __PROJECT__ y __BUCKET__.
-- External tables con esquema explícito: leen directo del bucket y toleran campos extra.

CREATE SCHEMA IF NOT EXISTS `__PROJECT__.secop` OPTIONS (location = "US");

CREATE OR REPLACE EXTERNAL TABLE `__PROJECT__.secop.procesos` (
  notice_uid STRING, referencia STRING, entidad STRING, nit STRING,
  descripcion STRING, tipo_filtro STRING, cuantia_cop FLOAT64,
  fecha_publicacion STRING, fecha_limite STRING,
  region_detectada STRING, keyword_detectada STRING, url_detalle STRING,
  num_documentos INT64, descarga_completa BOOL, actualizado_en STRING, ruta_gcs STRING
)
OPTIONS (format = 'NEWLINE_DELIMITED_JSON', ignore_unknown_values = TRUE,
         uris = ['gs://__BUCKET__/secop/raw/*metadata.json']);

CREATE OR REPLACE EXTERNAL TABLE `__PROJECT__.secop.analisis` (
  estado_global STRING, resumen STRING,
  notice_uid STRING, referencia STRING, entidad STRING, nit STRING,
  url_detalle STRING, fecha_limite STRING, cuantia_cop FLOAT64,
  num_checks INT64, num_pendientes INT64,
  checks_json STRING, pendientes_json STRING,
  descarga_completa BOOL, analizado_en TIMESTAMP, ruta_gcs STRING
)
OPTIONS (format = 'NEWLINE_DELIMITED_JSON', ignore_unknown_values = TRUE,
         uris = ['gs://__BUCKET__/secop/analisis/*analisis.json']);

-- Día a día: qué puedo presentar, primero lo que cumple
CREATE OR REPLACE VIEW `__PROJECT__.secop.oportunidades_evaluadas` AS
SELECT estado_global, resumen, referencia, entidad, cuantia_cop, fecha_limite,
       num_pendientes AS pendientes_manual, url_detalle, analizado_en, ruta_gcs
FROM `__PROJECT__.secop.analisis`
ORDER BY CASE estado_global WHEN 'CUMPLE' THEN 1 WHEN 'REVISAR' THEN 2 ELSE 3 END,
         cuantia_cop DESC;

-- Detalle por requisito (una fila por check)
CREATE OR REPLACE VIEW `__PROJECT__.secop.checks` AS
SELECT a.referencia, a.entidad, a.estado_global,
       JSON_VALUE(c, '$.requisito') AS requisito,
       JSON_VALUE(c, '$.estado')    AS estado,
       JSON_VALUE(c, '$.detalle')   AS detalle,
       JSON_VALUE(c, '$.evidencia.documento') AS documento,
       SAFE_CAST(JSON_VALUE(c, '$.evidencia.pagina') AS INT64) AS pagina,
       JSON_VALUE(c, '$.evidencia.cita') AS cita
FROM `__PROJECT__.secop.analisis` a,
     UNNEST(JSON_QUERY_ARRAY(a.checks_json)) AS c;
