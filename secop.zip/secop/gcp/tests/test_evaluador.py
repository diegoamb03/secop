"""Pruebas del evaluador (reglas cumple / no cumple). Correr: python -m pytest gcp/tests -q"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "analizador"))
from evaluador import evaluar, codigo_coincide, CUMPLE, NO_CUMPLE, REVISAR

EV = {"documento": "Pliego", "pagina": 12, "cita": "..."}
PERFIL = {
    "smmlv_vigente": 1_500_000,
    "rup": {"codigos_unspsc": ["30171500", "40141600", "31160000"]},
    "indicadores": {"liquidez": 2.1, "endeudamiento": 0.45, "cobertura_intereses": "indeterminado",
                    "capital_trabajo": 350_000_000, "rentabilidad_patrimonio": 0.08, "rentabilidad_activo": 5},
    "experiencia": [
        {"consecutivo_rup": 1, "valor_smmlv": 300, "codigos_unspsc": ["40141600"]},
        {"consecutivo_rup": 2, "valor_smmlv": 150, "codigos_unspsc": ["30171500", "40141600"]},
        {"consecutivo_rup": 3, "valor_smmlv": 900, "codigos_unspsc": ["72141000"]},
    ],
}

def ext(**kw):
    base = {"presupuesto_oficial_cop": 600_000_000, "requiere_rup": None,
            "codigos_unspsc_rup": [], "rup_exige_todos": None, "min_codigos_rup": None,
            "indicadores": [], "experiencia": None, "otros_requisitos": [], "observaciones": None}
    base.update(kw); return base

def ind(nombre, op, valor=None, pct=None):
    return {"nombre": nombre, "operador": op, "valor": valor, "porcentaje_del_presupuesto": pct, "evidencia": EV}

def test_codigos_a_nivel_clase():
    assert codigo_coincide("40141609", "40141600")      # mismo 6 dígitos (clase)
    assert codigo_coincide("401416", "40141600")
    assert not codigo_coincide("40141700", "40141600")
    assert codigo_coincide("31", "31160000")            # nivel segmento

def test_todo_cumple():
    r = evaluar(ext(codigos_unspsc_rup=["40141600", "30171500"], rup_exige_todos=True,
                    indicadores=[ind("Índice de Liquidez", ">=", 1.5), ind("endeudamiento", "<=", 0.7),
                                 ind("Razón de cobertura de intereses", ">=", 2),
                                 ind("capital de trabajo", ">=", pct=0.5)],
                    experiencia={"valor_minimo_smmlv": 400, "porcentaje_del_presupuesto": None,
                                 "max_contratos": 2, "codigos_unspsc": ["40141600"],
                                 "min_codigos_por_contrato": 1, "evidencia": EV}), PERFIL)
    assert r["estado_global"] == CUMPLE, r["resumen"]

def test_endeudamiento_en_porcentaje_no_cumple():
    r = evaluar(ext(indicadores=[ind("endeudamiento", "<=", 40)]), PERFIL)   # 40% vs 0.45
    assert r["estado_global"] == NO_CUMPLE and "endeudamiento" in r["resumen"].lower()

def test_capital_trabajo_porcentaje_presupuesto():
    r = evaluar(ext(presupuesto_oficial_cop=1_000_000_000, indicadores=[ind("capital_trabajo", ">=", pct=0.5)]), PERFIL)
    assert r["checks"][0]["estado"] == NO_CUMPLE   # exige 500M, tiene 350M

def test_experiencia_respeta_max_contratos_y_codigos():
    # Solo contratos 1 y 2 tienen el código; el de 900 no cuenta. Máx 1 contrato -> 300 < 400
    r = evaluar(ext(experiencia={"valor_minimo_smmlv": 400, "porcentaje_del_presupuesto": None,
                                 "max_contratos": 1, "codigos_unspsc": ["40141600"],
                                 "min_codigos_por_contrato": None, "evidencia": EV}), PERFIL)
    c = r["checks"][0]
    assert c["estado"] == NO_CUMPLE and c["smmlv_acreditados"] == 300

def test_experiencia_como_porcentaje_presupuesto():
    # 100% de 600M / 1.5M = 400 SMMLV; contratos 1+2 = 450 -> cumple
    r = evaluar(ext(experiencia={"valor_minimo_smmlv": None, "porcentaje_del_presupuesto": 1.0,
                                 "max_contratos": 3, "codigos_unspsc": ["401416"],
                                 "min_codigos_por_contrato": None, "evidencia": EV}), PERFIL)
    assert r["checks"][0]["estado"] == CUMPLE

def test_rup_parcial_sin_minimo_es_revisar():
    r = evaluar(ext(codigos_unspsc_rup=["40141600", "95121700"]), PERFIL)
    assert r["estado_global"] == REVISAR

def test_rup_minimo_explicito():
    r = evaluar(ext(codigos_unspsc_rup=["40141600", "95121700"], min_codigos_rup=1), PERFIL)
    assert r["estado_global"] == CUMPLE

def test_minima_cuantia_sin_rup():
    r = evaluar(ext(requiere_rup=False, codigos_unspsc_rup=["99999999"],
                    otros_requisitos=[{"tipo": "certificacion", "descripcion": "ISO 9001", "evidencia": None}]), PERFIL)
    assert r["estado_global"] == REVISAR            # no hay nada cuantitativo que evaluar
    assert len(r["pendientes_manual"]) == 1

def test_falta_dato_en_perfil_es_revisar():
    perfil = {**PERFIL, "indicadores": {"liquidez": 2.0}}
    r = evaluar(ext(indicadores=[ind("liquidez", ">=", 1.5), ind("rentabilidad del activo", ">=", 0.03)]), perfil)
    assert r["estado_global"] == REVISAR

def test_rentabilidad_perfil_en_porcentaje():
    r = evaluar(ext(indicadores=[ind("rentabilidad_activo", ">=", 0.03)]), PERFIL)  # perfil tiene 5 (=5%)
    assert r["checks"][0]["estado"] == CUMPLE

def test_exige_rup_sin_codigos_es_revisar():
    r = evaluar(ext(requiere_rup=True), PERFIL)
    assert r["checks"][0]["estado"] == REVISAR
