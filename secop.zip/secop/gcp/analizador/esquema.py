"""
Esquema de lo que Gemini extrae de los pliegos.
Sin valores por defecto a propósito: la API de Gemini no los acepta en response_schema.
Optional = el campo es obligatorio en la respuesta pero puede venir null.
"""

from typing import List, Optional

from pydantic import BaseModel, Field


class Evidencia(BaseModel):
    documento: str = Field(description="Nombre del documento de donde sale el dato")
    pagina: Optional[int] = Field(description="Página del PDF, si se puede identificar")
    cita: str = Field(description="Texto literal corto del pliego (máx. 300 caracteres)")


class Indicador(BaseModel):
    nombre: str = Field(description=(
        "Uno de: liquidez, endeudamiento, cobertura_intereses, capital_trabajo, "
        "rentabilidad_patrimonio, rentabilidad_activo, otro"))
    operador: str = Field(description="'>=', '<=', '>' o '<'")
    valor: Optional[float] = Field(description=(
        "Umbral. Porcentajes como decimal (70% -> 0.70). Liquidez y cobertura en veces (1.5). "
        "Capital de trabajo en COP si es valor fijo"))
    porcentaje_del_presupuesto: Optional[float] = Field(description=(
        "Solo capital de trabajo exigido como % del presupuesto oficial, como decimal (50% -> 0.5)"))
    evidencia: Evidencia


class Experiencia(BaseModel):
    valor_minimo_smmlv: Optional[float] = Field(description="Valor mínimo exigido expresado en SMMLV")
    porcentaje_del_presupuesto: Optional[float] = Field(description=(
        "Si se exige como % o veces el presupuesto oficial, como decimal (100% -> 1.0, 2 veces -> 2.0)"))
    max_contratos: Optional[int] = Field(description="Número máximo de contratos que se pueden aportar")
    codigos_unspsc: List[str] = Field(description="Códigos UNSPSC que debe acreditar la experiencia")
    min_codigos_por_contrato: Optional[int] = Field(description=(
        "Cuántos de esos códigos debe tener cada contrato, si el pliego lo dice"))
    evidencia: Evidencia


class OtroRequisito(BaseModel):
    tipo: str = Field(description=(
        "Uno de: juridico, tecnico, documental, garantia, visita_obligatoria, certificacion, "
        "personal, equipo, capacidad_residual, otro"))
    descripcion: str
    evidencia: Optional[Evidencia]


class Extraccion(BaseModel):
    presupuesto_oficial_cop: Optional[float] = Field(description="Presupuesto oficial en COP")
    requiere_rup: Optional[bool] = Field(description="true si exige RUP; false si dice que no; null si no lo menciona")
    codigos_unspsc_rup: List[str] = Field(description="Códigos UNSPSC en los que el proponente debe estar inscrito en el RUP")
    rup_exige_todos: Optional[bool] = Field(description="true si exige estar inscrito en TODOS los códigos listados")
    min_codigos_rup: Optional[int] = Field(description="Si exige 'al menos N' de los códigos, ese N")
    indicadores: List[Indicador]
    experiencia: Optional[Experiencia]
    otros_requisitos: List[OtroRequisito]
    observaciones: Optional[str] = Field(description=(
        "Ambigüedades o contradicciones entre documentos que un humano debería revisar"))
