"""
Evaluador: compara los requisitos extraídos contra el perfil de la empresa.
Reglas fijas y trazables; nada de LLM aquí.

Estados por requisito:
  CUMPLE     el dato de la empresa satisface el umbral
  NO_CUMPLE  el dato de la empresa no alcanza
  REVISAR    falta información (en el pliego o en el perfil) o el pliego es ambiguo

Estado global:
  NO_CUMPLE si algún requisito cuantitativo no se cumple
  REVISAR   si ninguno falla pero alguno no se pudo evaluar (o no se extrajo nada)
  CUMPLE    si todos los cuantitativos se cumplen
Los requisitos cualitativos (certificaciones, visitas, garantías...) van aparte en
`pendientes_manual`: no cambian el estado global, pero hay que revisarlos.
"""

import re
import unicodedata

CUMPLE, NO_CUMPLE, REVISAR = "CUMPLE", "NO_CUMPLE", "REVISAR"
PORCENTUALES = {"endeudamiento", "rentabilidad_patrimonio", "rentabilidad_activo"}
OPS = {">=": lambda a, b: a >= b, ">": lambda a, b: a > b,
       "<=": lambda a, b: a <= b, "<": lambda a, b: a < b}
ETIQUETAS = {
    "liquidez": "Índice de liquidez", "endeudamiento": "Nivel de endeudamiento",
    "cobertura_intereses": "Razón de cobertura de intereses", "capital_trabajo": "Capital de trabajo",
    "rentabilidad_patrimonio": "Rentabilidad del patrimonio", "rentabilidad_activo": "Rentabilidad del activo",
}


# ── utilidades ───────────────────────────────────────────────────────

def _num(v):
    try:
        f = float(v)
        return None if f != f else f
    except (TypeError, ValueError):
        return None


def _sin_tildes(s) -> str:
    return unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode().lower()


def normalizar_indicador(nombre: str) -> str:
    s = _sin_tildes(nombre).replace("_", " ")
    if "liquidez" in s:
        return "liquidez"
    if "endeud" in s:
        return "endeudamiento"
    if "cobertura" in s:
        return "cobertura_intereses"
    if "capital" in s and "trabajo" in s:
        return "capital_trabajo"
    if "rentabilidad" in s and "patrimonio" in s:
        return "rentabilidad_patrimonio"
    if "rentabilidad" in s and "activo" in s:
        return "rentabilidad_activo"
    return "otro"


def _pct(v, umbral_pct=1.0):
    """70 -> 0.70 cuando claramente viene en porcentaje."""
    v = _num(v)
    if v is None:
        return None
    return v / 100 if abs(v) > umbral_pct else v


def _digitos(c) -> str:
    return re.sub(r"\D", "", str(c or ""))


def codigo_coincide(requerido, de_empresa) -> bool:
    """
    El RUP clasifica a nivel de CLASE (6 dígitos). Se compara hasta 6 dígitos
    o menos si el pliego exige a nivel de segmento/familia.
    """
    r, e = _digitos(requerido), _digitos(de_empresa)
    n = min(len(r), 6)
    return n >= 2 and len(e) >= n and r[:n] == e[:n]


def _check(requisito, estado, detalle, evidencia=None, **extra):
    return {"requisito": requisito, "estado": estado, "detalle": detalle,
            "evidencia": evidencia, **extra}


def _fmt(v):
    v = _num(v)
    if v is None:
        return "—"
    return f"{v:,.0f}" if abs(v) >= 1000 else f"{v:.2f}"


# ── RUP ──────────────────────────────────────────────────────────────

def evaluar_rup(ext: dict, perfil: dict) -> list[dict]:
    requeridos = [c for c in ext.get("codigos_unspsc_rup") or [] if _digitos(c)]
    requiere   = ext.get("requiere_rup")

    if requiere is False:
        return []
    if not requeridos:
        if requiere:
            return [_check("RUP · códigos UNSPSC", REVISAR,
                           "El pliego exige RUP pero no se identificaron los códigos")]
        return []

    de_empresa = (perfil.get("rup") or {}).get("codigos_unspsc") or []
    if not de_empresa:
        return [_check("RUP · códigos UNSPSC", REVISAR, "El perfil no tiene códigos UNSPSC del RUP")]

    ok    = [c for c in requeridos if any(codigo_coincide(c, e) for e in de_empresa)]
    falta = [c for c in requeridos if c not in ok]

    if ext.get("rup_exige_todos"):
        minimo = len(requeridos)
    else:
        minimo = ext.get("min_codigos_rup")

    detalle = f"Tiene {len(ok)} de {len(requeridos)} códigos exigidos"
    if falta:
        detalle += f" · faltan: {', '.join(falta)}"

    if minimo is None:
        if not falta:
            estado = CUMPLE
        elif ok:
            estado = REVISAR
            detalle += " · el pliego no dice cuántos se exigen"
        else:
            estado = NO_CUMPLE
    else:
        estado = CUMPLE if len(ok) >= int(minimo) else NO_CUMPLE
        detalle += f" · mínimo exigido: {minimo}"

    return [_check("RUP · códigos UNSPSC", estado, detalle, codigos_ok=ok, codigos_faltantes=falta)]


# ── Indicadores financieros ──────────────────────────────────────────

def evaluar_indicadores(ext: dict, perfil: dict, presupuesto) -> list[dict]:
    checks = []
    ind_empresa = perfil.get("indicadores") or {}

    for ind in ext.get("indicadores") or []:
        nombre = normalizar_indicador(ind.get("nombre"))
        etiqueta = ETIQUETAS.get(nombre, f"Indicador: {ind.get('nombre')}")
        ev = ind.get("evidencia")
        op = (ind.get("operador") or ">=").strip()
        op = op if op in OPS else ">="

        if nombre == "otro":
            checks.append(_check(etiqueta, REVISAR, "Indicador no estándar: revisar manualmente", ev))
            continue

        # Umbral
        if nombre == "capital_trabajo" and _num(ind.get("valor")) is None \
                and _num(ind.get("porcentaje_del_presupuesto")) is not None:
            pct = _pct(ind["porcentaje_del_presupuesto"], umbral_pct=3)
            if _num(presupuesto) is None:
                checks.append(_check(etiqueta, REVISAR,
                                     f"Se exige {pct:.0%} del presupuesto pero no hay presupuesto", ev))
                continue
            umbral = pct * float(presupuesto)
        elif nombre in PORCENTUALES:
            umbral = _pct(ind.get("valor"))
        else:
            umbral = _num(ind.get("valor"))

        if umbral is None:
            checks.append(_check(etiqueta, REVISAR, "No se pudo leer el umbral exigido", ev))
            continue

        # Valor de la empresa
        valor = ind_empresa.get(nombre)
        if nombre == "cobertura_intereses" and _sin_tildes(valor) == "indeterminado":
            checks.append(_check(etiqueta, CUMPLE,
                                 "Empresa sin gastos de intereses (indeterminado). "
                                 "Normalmente se acepta; verifica que el pliego no diga lo contrario",
                                 ev, umbral=umbral))
            continue
        valor = _pct(valor) if nombre in PORCENTUALES else _num(valor)
        if valor is None:
            checks.append(_check(etiqueta, REVISAR, "El perfil no tiene este indicador", ev, umbral=umbral))
            continue

        estado = CUMPLE if OPS[op](valor, umbral) else NO_CUMPLE
        checks.append(_check(etiqueta, estado,
                             f"Empresa {_fmt(valor)} · exigido {op} {_fmt(umbral)}",
                             ev, valor_empresa=valor, umbral=umbral, operador=op))
    return checks


# ── Experiencia ──────────────────────────────────────────────────────

def evaluar_experiencia(ext: dict, perfil: dict, presupuesto) -> list[dict]:
    exp = ext.get("experiencia")
    if not exp:
        return []
    etiqueta = "Experiencia"
    ev = exp.get("evidencia")
    smmlv = _num(perfil.get("smmlv_vigente"))

    requerido = _num(exp.get("valor_minimo_smmlv"))
    if requerido is None and _num(exp.get("porcentaje_del_presupuesto")) is not None:
        pct = _pct(exp["porcentaje_del_presupuesto"], umbral_pct=10)
        if _num(presupuesto) is None or not smmlv:
            return [_check(etiqueta, REVISAR,
                           "Se exige % del presupuesto pero falta el presupuesto o smmlv_vigente en el perfil", ev)]
        requerido = pct * float(presupuesto) / smmlv

    codigos = [c for c in exp.get("codigos_unspsc") or [] if _digitos(c)]
    min_por_contrato = int(exp.get("min_codigos_por_contrato") or 1)
    max_contratos = exp.get("max_contratos")

    contratos = perfil.get("experiencia") or []
    if not contratos:
        return [_check(etiqueta, REVISAR, "El perfil no tiene contratos de experiencia", ev)]

    elegibles = []
    for c in contratos:
        if codigos:
            n = sum(1 for r in codigos if any(codigo_coincide(r, e) for e in c.get("codigos_unspsc") or []))
            if n < min(min_por_contrato, len(codigos)):
                continue
        if _num(c.get("valor_smmlv")) is not None:
            elegibles.append(c)

    elegibles.sort(key=lambda c: float(c["valor_smmlv"]), reverse=True)
    usados = elegibles[: int(max_contratos)] if max_contratos else elegibles
    suma = sum(float(c["valor_smmlv"]) for c in usados)
    ids = [c.get("consecutivo_rup") or c.get("objeto", "")[:40] for c in usados]

    if requerido is None:
        detalle = (f"No se pudo leer el valor exigido · la empresa tiene {len(elegibles)} contratos "
                   f"con los códigos ({suma:,.1f} SMMLV)")
        return [_check(etiqueta, REVISAR, detalle, ev, contratos_usados=ids)]

    estado = CUMPLE if suma >= requerido else NO_CUMPLE
    detalle = (f"Acredita {suma:,.1f} SMMLV con {len(usados)} contrato(s) · exigido {requerido:,.1f} SMMLV")
    if max_contratos:
        detalle += f" (máx. {max_contratos} contratos)"
    if codigos and not elegibles:
        detalle += " · ningún contrato tiene los códigos exigidos"
    return [_check(etiqueta, estado, detalle, ev, smmlv_acreditados=suma,
                   smmlv_exigidos=requerido, contratos_usados=ids)]


# ── Global ───────────────────────────────────────────────────────────

def evaluar(ext: dict, perfil: dict, presupuesto_fallback=None) -> dict:
    presupuesto = _num(ext.get("presupuesto_oficial_cop")) or _num(presupuesto_fallback)

    checks = (evaluar_rup(ext, perfil)
              + evaluar_indicadores(ext, perfil, presupuesto)
              + evaluar_experiencia(ext, perfil, presupuesto))

    pendientes = [{"tipo": o.get("tipo"), "descripcion": o.get("descripcion"),
                   "evidencia": o.get("evidencia")}
                  for o in ext.get("otros_requisitos") or []]

    estados = [c["estado"] for c in checks]
    if NO_CUMPLE in estados:
        global_ = NO_CUMPLE
    elif REVISAR in estados or not checks:
        global_ = REVISAR
    else:
        global_ = CUMPLE

    fallas = [f"{c['requisito']}: {c['detalle']}" for c in checks if c["estado"] == NO_CUMPLE]
    dudas  = [c["requisito"] for c in checks if c["estado"] == REVISAR]
    if global_ == NO_CUMPLE:
        resumen = "No cumple — " + " | ".join(fallas)
    elif global_ == REVISAR:
        resumen = ("Sin requisitos cuantitativos extraídos" if not checks
                   else "Revisar — sin evaluar: " + ", ".join(dudas))
    else:
        resumen = f"Cumple los {len(checks)} requisitos cuantitativos"
    if pendientes:
        resumen += f" · {len(pendientes)} requisito(s) cualitativo(s) para revisar"

    return {
        "estado_global":    global_,
        "resumen":          resumen,
        "presupuesto_usado": presupuesto,
        "checks":           checks,
        "pendientes_manual": pendientes,
    }
