"""
SECOP Analizador v1.0 — Cloud Run Job

Recorre gs://$GCS_BUCKET/$GCS_PREFIX/raw/**/metadata.json y, para cada proceso NUEVO o
ACTUALIZADO (p. ej. llegó una adenda) desde su último análisis:
  1. Selecciona los PDFs relevantes (pliego, estudios previos, invitación, adendas...)
  2. Gemini extrae los requisitos (extractor.py)
  3. Reglas fijas comparan contra el perfil de la empresa (evaluador.py)
  4. Escribe $GCS_PREFIX/analisis/.../analisis.json (una línea -> BigQuery)

Perfil de la empresa: gs://$GCS_BUCKET/$GCS_PREFIX/config/perfil_empresa.json
(se actualiza subiendo el archivo; no hay que redesplegar)
"""

import json
import logging
import os
import re
import sys
from datetime import datetime, timezone

from google.cloud import storage

from evaluador import evaluar
from extractor import BACKEND, MODELO, extraer

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s", stream=sys.stdout)
log = logging.getLogger("analizador")

BUCKET        = os.environ["GCS_BUCKET"]
PREFIX        = os.getenv("GCS_PREFIX", "secop").strip("/")
MAX_PROCESOS  = int(os.getenv("MAX_PROCESOS", "20"))
MAX_DOCS      = int(os.getenv("MAX_DOCS", "6"))
MAX_MB_TOTAL  = float(os.getenv("MAX_MB_TOTAL", "45"))
PERFIL_OBJ    = f"{PREFIX}/config/perfil_empresa.json"

# Qué documentos traen requisitos habilitantes (peso más alto = más prioridad)
PESOS = [
    (r"adenda", 6),
    (r"pliego.*definitiv", 6),
    (r"pliego", 5), (r"condiciones", 5),
    (r"invitaci", 5),
    (r"estudio.*previo|estudios.*previo|estudio.*sector", 4),
    (r"requisit|habilitant|evaluaci", 4),
    (r"anexo.*t[eé]cnic|especificaci|ficha.*t[eé]cnic", 2),
    (r"anexo|formato", 1),
    (r"acta|aviso|resoluci|cronograma|certificado.*disponibilidad|cdp", -3),
]


def puntaje(nombre: str) -> int:
    n = (nombre or "").lower()
    return sum(p for pat, p in PESOS if re.search(pat, n))


def seleccionar_docs(meta: dict) -> tuple[list[dict], list[str]]:
    """PDFs ordenados por relevancia, con tope de cantidad y tamaño. Retorna (docs, omitidos)."""
    candidatos, omitidos = [], []
    for d in meta.get("documentos", []):
        if d.get("estado") != "ok" or not d.get("archivo"):
            continue
        nombre = d.get("nombre_original") or d["archivo"].rsplit("/", 1)[-1]
        if not d["archivo"].lower().endswith(".pdf"):
            omitidos.append(f"{nombre} (no es PDF)")
            continue
        candidatos.append({"archivo": d["archivo"], "nombre": nombre,
                           "bytes": d.get("bytes") or 0, "puntaje": puntaje(nombre)})

    candidatos.sort(key=lambda d: (-d["puntaje"], d["bytes"]))
    elegidos, total = [], 0
    for d in candidatos:
        mb = d["bytes"] / 1_048_576
        if len(elegidos) >= MAX_DOCS or total + mb > MAX_MB_TOTAL:
            omitidos.append(f"{d['nombre']} (fuera del tope)")
            continue
        elegidos.append(d)
        total += mb
    return elegidos, omitidos


def ruta_analisis(meta_obj: str) -> str:
    base = meta_obj.replace(f"{PREFIX}/raw/", f"{PREFIX}/analisis/", 1).rsplit("/", 1)[0]
    return f"{base}/analisis.json"


def main():
    client = storage.Client()
    bucket = client.bucket(BUCKET)

    perfil = json.loads(bucket.blob(PERFIL_OBJ).download_as_text())
    if not perfil.get("smmlv_vigente"):
        log.warning("perfil_empresa.json sin smmlv_vigente: la experiencia en % del presupuesto quedará en REVISAR")

    metas = [b for b in client.list_blobs(BUCKET, prefix=f"{PREFIX}/raw/")
             if b.name.endswith("/metadata.json")]
    analizados = {b.name: b.updated for b in client.list_blobs(BUCKET, prefix=f"{PREFIX}/analisis/")
                  if b.name.endswith("/analisis.json")}

    pendientes = [m for m in metas
                  if ruta_analisis(m.name) not in analizados
                  or analizados[ruta_analisis(m.name)] < m.updated]
    pendientes.sort(key=lambda b: b.updated, reverse=True)

    log.info(f"Procesos: {len(metas)} · pendientes de análisis: {len(pendientes)} · "
             f"se analizan hasta {MAX_PROCESOS} · modelo {MODELO} ({BACKEND})")

    ok = errores = 0
    for m in pendientes[:MAX_PROCESOS]:
        meta = json.loads(m.download_as_text())
        ref = meta.get("referencia")
        try:
            docs, omitidos = seleccionar_docs(meta)
            base = {
                "notice_uid":        meta.get("notice_uid"),
                "referencia":        ref,
                "entidad":           meta.get("entidad"),
                "nit":               meta.get("nit"),
                "url_detalle":       meta.get("url_detalle"),
                "fecha_limite":      meta.get("fecha_limite"),
                "cuantia_cop":       meta.get("cuantia_cop"),
                "ruta_gcs":          meta.get("ruta_gcs"),
                "documentos_analizados": [d["nombre"] for d in docs],
                "documentos_omitidos":   omitidos,
                "descarga_completa": meta.get("descarga_completa"),
                "analizado_en":      datetime.now(timezone.utc).isoformat(timespec="seconds"),
            }

            if not docs:
                resultado = {**base, "estado_global": "REVISAR",
                             "resumen": "Sin PDFs para analizar", "checks": [],
                             "pendientes_manual": [], "extraccion": None, "uso": None}
            else:
                contexto = {"referencia": ref or "", "entidad": meta.get("entidad") or "",
                            "objeto": meta.get("objeto") or meta.get("descripcion_detalle")
                                      or meta.get("descripcion") or ""}
                ext, uso = extraer(bucket, docs, contexto)
                ext_dict = ext.model_dump()
                ev = evaluar(ext_dict, perfil, presupuesto_fallback=meta.get("cuantia_cop"))
                resultado = {**base, **ev, "extraccion": ext_dict, "uso": uso}
                if not meta.get("descarga_completa"):
                    resultado["resumen"] += " · ojo: descarga incompleta"

            # Campos planos para BigQuery (el detalle completo va como string JSON)
            resultado["num_checks"]     = len(resultado.get("checks") or [])
            resultado["num_pendientes"] = len(resultado.get("pendientes_manual") or [])
            resultado["checks_json"]    = json.dumps(resultado.get("checks") or [], ensure_ascii=False)
            resultado["pendientes_json"] = json.dumps(resultado.get("pendientes_manual") or [], ensure_ascii=False)

            bucket.blob(ruta_analisis(m.name)).upload_from_string(
                json.dumps(resultado, ensure_ascii=False), content_type="application/json")
            log.info(f"  {resultado['estado_global']:<9} {ref} · {resultado['resumen'][:120]}")
            ok += 1
        except Exception as e:
            # No se escribe analisis.json: el proceso se reintenta en la próxima corrida
            log.error(f"  ERROR     {ref}: {e}")
            errores += 1

    log.info(f"Listo: {ok} analizados · {errores} con error · "
             f"{max(0, len(pendientes) - MAX_PROCESOS)} quedan para la próxima corrida")
    if errores and not ok:
        sys.exit(1)


if __name__ == "__main__":
    main()
