"""
Extracción de requisitos con Gemini.

Dos backends (variable GEMINI_BACKEND):
  - "api"    (default): Gemini Developer API con GEMINI_API_KEY. Tiene capa gratuita con
                        límites de uso. Aquí solo viajan pliegos PÚBLICOS; el perfil de la
                        empresa nunca se envía al modelo.
  - "vertex": Vertex AI con la cuenta de servicio del Job. Lee los PDFs directo desde gs://.
              Se paga por token.

El modelo solo EXTRAE; la decisión cumple / no cumple la toma evaluador.py.
"""

import io
import logging
import os
import time

from google import genai
from google.genai import types

from esquema import Extraccion

log = logging.getLogger("extractor")

MODELO     = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
BACKEND    = os.getenv("GEMINI_BACKEND", "api").lower()
INLINE_MAX = 18 * 1024 * 1024  # límite práctico de datos inline por request

PROMPT = """Eres analista de contratación pública en Colombia (SECOP II).
Arriba están los documentos del proceso {referencia} de {entidad}.
Objeto: {objeto}

Extrae SOLO los requisitos habilitantes y condiciones para poder participar, según el esquema JSON.

Reglas:
- Solo lo que esté escrito en los documentos. No supongas ni completes con conocimiento general.
  Si un dato no aparece: null o lista vacía.
- Si una adenda modifica un requisito, usa el valor de la adenda más reciente y cita la adenda.
- Indicadores financieros: umbral numérico. Porcentajes como decimal (70% -> 0.70).
  Liquidez y razón de cobertura de intereses en veces (1.5).
- Capital de trabajo: valor fijo en COP en `valor`; si es % del presupuesto, en `porcentaje_del_presupuesto`.
- Experiencia: si está en SMMLV, en `valor_minimo_smmlv`; si es % o veces el presupuesto oficial,
  en `porcentaje_del_presupuesto` como decimal (100% -> 1.0).
- Códigos UNSPSC: solo dígitos, sin puntos ni espacios (8 dígitos, o 6 si el pliego exige a nivel de clase).
- En mínima cuantía normalmente no se exige RUP: si el documento lo dice, requiere_rup=false.
- Cada requisito cuantitativo lleva evidencia: documento, página y cita literal corta.
- otros_requisitos: lo que un proponente debe cumplir y no es cuantificable (certificaciones, visita
  obligatoria, garantías, personal, equipos, capacidad residual, documentos especiales).
- En observaciones anota contradicciones entre documentos o requisitos ambiguos.
"""


def _cliente() -> genai.Client:
    if BACKEND == "vertex":
        return genai.Client(vertexai=True,
                            project=os.environ["GOOGLE_CLOUD_PROJECT"],
                            location=os.getenv("VERTEX_LOCATION", "us-central1"))
    return genai.Client(api_key=os.environ["GEMINI_API_KEY"])


def _esperar_activo(client, f, timeout=120):
    t0 = time.time()
    while getattr(f, "state", None) and str(f.state).endswith("PROCESSING"):
        if time.time() - t0 > timeout:
            raise TimeoutError(f"Archivo {f.name} sigue procesando")
        time.sleep(3)
        f = client.files.get(name=f.name)
    return f


def extraer(bucket, docs: list[dict], contexto: dict) -> tuple[Extraccion, dict]:
    """
    docs: [{"archivo": objeto_gcs, "nombre": str, "bytes": int}]
    Retorna (extracción, info de uso).
    """
    client   = _cliente()
    parts    = []
    subidos  = []
    inline   = 0

    try:
        for d in docs:
            parts.append(types.Part.from_text(text=f"=== DOCUMENTO: {d['nombre']} ==="))
            if BACKEND == "vertex":
                parts.append(types.Part.from_uri(file_uri=f"gs://{bucket.name}/{d['archivo']}",
                                                 mime_type="application/pdf"))
                continue
            data = bucket.blob(d["archivo"]).download_as_bytes()
            if inline + len(data) <= INLINE_MAX:
                parts.append(types.Part.from_bytes(data=data, mime_type="application/pdf"))
                inline += len(data)
            else:
                f = client.files.upload(file=io.BytesIO(data), config=types.UploadFileConfig(
                    mime_type="application/pdf", display_name=d["nombre"][:100]))
                f = _esperar_activo(client, f)
                subidos.append(f.name)
                parts.append(types.Part.from_uri(file_uri=f.uri, mime_type="application/pdf"))

        parts.append(types.Part.from_text(text=PROMPT.format(**contexto)))
        config = types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=Extraccion,
            temperature=0,
        )

        ultimo_error = None
        for intento in range(3):
            try:
                resp = client.models.generate_content(
                    model=MODELO,
                    contents=[types.Content(role="user", parts=parts)],
                    config=config,
                )
                ext = resp.parsed if isinstance(resp.parsed, Extraccion) \
                    else Extraccion.model_validate_json(resp.text)
                uso = resp.usage_metadata
                info = {
                    "modelo":        MODELO,
                    "backend":       BACKEND,
                    "tokens_input":  getattr(uso, "prompt_token_count", None),
                    "tokens_output": getattr(uso, "candidates_token_count", None),
                }
                return ext, info
            except Exception as e:
                ultimo_error = e
                msg = str(e)
                if "429" in msg or "RESOURCE_EXHAUSTED" in msg or "503" in msg:
                    espera = 30 * (intento + 1)
                    log.warning(f"  límite/sobrecarga de Gemini, reintento en {espera}s")
                    time.sleep(espera)
                    continue
                raise
        raise ultimo_error
    finally:
        for name in subidos:
            try:
                client.files.delete(name=name)
            except Exception:
                pass
