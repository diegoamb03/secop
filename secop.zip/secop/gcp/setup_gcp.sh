#!/usr/bin/env bash
# Setup SECOP en GCP. Correr desde Cloud Shell o con gcloud instalado:
#   PROJECT_ID=mi-proyecto BUCKET=mi-bucket-secop GEMINI_API_KEY=xxx bash setup_gcp.sh
set -euo pipefail

: "${PROJECT_ID:?Define PROJECT_ID}"
: "${BUCKET:?Define BUCKET (nombre global único, sin gs://)}"
: "${GEMINI_API_KEY:?Define GEMINI_API_KEY (https://aistudio.google.com/apikey)}"
REGION="${REGION:-us-central1}"          # región con capa gratuita de Storage y Cloud Run
GEMINI_MODEL="${GEMINI_MODEL:-gemini-2.5-flash}"
JOB="secop-analizador"
SA_NAME="secop-analizador"
SA="${SA_NAME}@${PROJECT_ID}.iam.gserviceaccount.com"
DIR="$(cd "$(dirname "$0")" && pwd)"

gcloud config set project "$PROJECT_ID"

echo "== APIs"
gcloud services enable storage.googleapis.com run.googleapis.com cloudscheduler.googleapis.com \
  secretmanager.googleapis.com bigquery.googleapis.com cloudbuild.googleapis.com \
  artifactregistry.googleapis.com

echo "== Bucket (privado, sin versionado)"
gcloud storage buckets describe "gs://$BUCKET" >/dev/null 2>&1 || \
  gcloud storage buckets create "gs://$BUCKET" --location="$REGION" \
    --uniform-bucket-level-access --public-access-prevention

echo "== Cuenta de servicio del Job (solo este bucket)"
gcloud iam service-accounts describe "$SA" >/dev/null 2>&1 || \
  gcloud iam service-accounts create "$SA_NAME" --display-name="SECOP analizador"
gcloud storage buckets add-iam-policy-binding "gs://$BUCKET" \
  --member="serviceAccount:$SA" --role="roles/storage.objectAdmin" >/dev/null

echo "== Secreto con la API key de Gemini"
if gcloud secrets describe gemini-api-key >/dev/null 2>&1; then
  printf "%s" "$GEMINI_API_KEY" | gcloud secrets versions add gemini-api-key --data-file=-
else
  printf "%s" "$GEMINI_API_KEY" | gcloud secrets create gemini-api-key --data-file=-
fi
gcloud secrets add-iam-policy-binding gemini-api-key \
  --member="serviceAccount:$SA" --role="roles/secretmanager.secretAccessor" >/dev/null

echo "== Perfil de la empresa"
if [ -f "$DIR/perfil_empresa.json" ]; then
  gcloud storage cp "$DIR/perfil_empresa.json" "gs://$BUCKET/secop/config/perfil_empresa.json"
else
  echo "   (!) Falta gcp/perfil_empresa.json: cópialo desde perfil_empresa.ejemplo.json y llénalo"
fi

echo "== Cloud Run Job"
gcloud run jobs deploy "$JOB" --source "$DIR/analizador" --region "$REGION" \
  --service-account "$SA" --cpu 1 --memory 1Gi --task-timeout 3600 --max-retries 0 \
  --set-env-vars "GCS_BUCKET=$BUCKET,GCS_PREFIX=secop,GEMINI_BACKEND=api,GEMINI_MODEL=$GEMINI_MODEL,MAX_PROCESOS=20" \
  --set-secrets "GEMINI_API_KEY=gemini-api-key:latest"

echo "== Programación diaria (9:00 a. m. Bogotá, después de la corrida local)"
gcloud run jobs add-iam-policy-binding "$JOB" --region "$REGION" \
  --member="serviceAccount:$SA" --role="roles/run.invoker" >/dev/null
gcloud scheduler jobs describe secop-analizador-diario --location "$REGION" >/dev/null 2>&1 || \
  gcloud scheduler jobs create http secop-analizador-diario --location "$REGION" \
    --schedule "0 9 * * *" --time-zone "America/Bogota" --http-method POST \
    --uri "https://run.googleapis.com/v2/projects/$PROJECT_ID/locations/$REGION/jobs/$JOB:run" \
    --oauth-service-account-email "$SA"

echo "== BigQuery"
sed -e "s/__PROJECT__/$PROJECT_ID/g" -e "s/__BUCKET__/$BUCKET/g" "$DIR/bigquery.sql" | \
  bq query --use_legacy_sql=false --project_id="$PROJECT_ID"

echo
echo "Listo. Probar ya:  gcloud run jobs execute $JOB --region $REGION --wait"
echo "Pendiente manual: alerta de presupuesto en Billing > Budgets & alerts (avisa, NO corta el gasto)"
